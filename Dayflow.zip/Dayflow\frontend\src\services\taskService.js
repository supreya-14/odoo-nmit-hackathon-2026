import api from './api';

export const taskService = {
  getAll: async () => {
    const res = await api.get('/tasks');
    return res.data;
  },
  getById: async (id) => {
    const res = await api.get(`/tasks/${id}`);
    return res.data;
  },
  create: async (data) => {
    const res = await api.post('/tasks', data);
    return res.data;
  },
  update: async (id, data) => {
    const res = await api.put(`/tasks/${id}`, data);
    return res.data;
  },
  delete: async (id) => {
    const res = await api.delete(`/tasks/${id}`);
    return res.data;
  },
};
