const express = require('express');
const router = express.Router();
const {
  getMyPerformance,
  getPerformanceByEmployeeId,
  createOrUpdatePerformance,
  generateAiInsights,
} = require('../controllers/performanceController');
const { protect } = require('../middleware/authMiddleware');
const { adminOnly } = require('../middleware/adminMiddleware');

router.get('/my', protect, getMyPerformance);
router.get('/:employeeId', protect, getPerformanceByEmployeeId);
router.post('/', protect, adminOnly, createOrUpdatePerformance);
router.post('/:employeeId/ai-insights', protect, adminOnly, generateAiInsights);

module.exports = router;
