const adminOnly = (req, res, next) => {
  if (req.user && (req.user.role === 'ADMIN' || req.user.role === 'HR')) {
    next();
  } else {
    res.status(403).json({ message: 'Access denied: Admin or HR permissions required' });
  }
};

module.exports = { adminOnly };
