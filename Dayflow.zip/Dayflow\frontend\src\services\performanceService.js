import api from './api';

export const performanceService = {
  getMyPerformance: async () => {
    const res = await api.get('/performance/my');
    return res.data;
  },
  getByEmployeeId: async (employeeId) => {
    const res = await api.get(`/performance/${employeeId}`);
    return res.data;
  },
  update: async (data) => {
    const res = await api.post('/performance', data);
    return res.data;
  },
  generateAiInsights: async (employeeId) => {
    const res = await api.post(`/performance/${employeeId}/ai-insights`);
    return res.data;
  },
};
