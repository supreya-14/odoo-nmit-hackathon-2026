import React, { useState, useEffect } from 'react';
import PerformanceCard from '../../components/PerformanceCard';
import LoadingSpinner from '../../components/LoadingSpinner';
import Modal from '../../components/Modal';
import { employeeService } from '../../services/employeeService';
import { performanceService } from '../../services/performanceService';
import { TrendingUp, Sparkles, User, Edit3 } from 'lucide-react';

const PerformanceDashboard = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmp, setSelectedEmp] = useState(null);
  const [performance, setPerformance] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generatingAi, setGeneratingAi] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [scoreForm, setScoreForm] = useState({
    taskCompletionScore: 85,
    attendanceScore: 90,
    onTimeDeliveryScore: 85,
    productivityScore: 88,
    managerFeedback: '',
  });

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const data = await employeeService.getAll();
      setEmployees(data || []);
      if (data && data.length > 0) {
        handleSelectEmployee(data[0]);
      }
    } catch (err) {
      console.error('Failed to fetch employees for performance:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectEmployee = async (emp) => {
    setSelectedEmp(emp);
    try {
      const perf = await performanceService.getByEmployeeId(emp._id);
      setPerformance(perf);
      setScoreForm({
        taskCompletionScore: perf.taskCompletionScore || 85,
        attendanceScore: perf.attendanceScore || 90,
        onTimeDeliveryScore: perf.onTimeDeliveryScore || 85,
        productivityScore: perf.productivityScore || 88,
        managerFeedback: perf.managerFeedback || '',
      });
    } catch (err) {
      console.error('Error fetching employee performance:', err);
    }
  };

  const handleGenerateAi = async () => {
    if (!selectedEmp) return;
    setGeneratingAi(true);
    try {
      const res = await performanceService.generateAiInsights(selectedEmp._id);
      setPerformance(res.performance);
    } catch (err) {
      alert('Gemini AI Insights generation failed.');
    } finally {
      setGeneratingAi(false);
    }
  };

  const handleUpdateScores = async (e) => {
    e.preventDefault();
    if (!selectedEmp) return;
    setSubmitting(true);
    try {
      const updated = await performanceService.update({
        employeeId: selectedEmp._id,
        ...scoreForm,
      });
      setPerformance(updated);
      setIsEditModalOpen(false);
    } catch (err) {
      alert('Failed to update scores');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading organization performance metrics & AI engine..." />;

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-indigo-400" /> Performance & Gemini AI Insights
          </h2>
          <p className="text-xs text-slate-400">Evaluate employee productivity, adjust weighted scores, and trigger Gemini AI analysis</p>
        </div>

        {selectedEmp && (
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors border border-slate-700 shrink-0"
          >
            <Edit3 className="w-4 h-4 text-indigo-400" />
            <span>Update Employee Scores</span>
          </button>
        )}
      </div>

      {/* Employee Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {employees.map((emp) => {
          const isSelected = selectedEmp?._id === emp._id;
          return (
            <button
              key={emp._id}
              onClick={() => handleSelectEmployee(emp)}
              className={`flex items-center gap-2.5 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                isSelected
                  ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-600/25'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 border-slate-800'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>{emp.firstName} {emp.lastName}</span>
            </button>
          );
        })}
      </div>

      {/* Main Performance Card Component */}
      {selectedEmp && performance ? (
        <PerformanceCard
          performance={performance}
          isAdmin={true}
          onGenerateAi={handleGenerateAi}
          isGeneratingAi={generatingAi}
        />
      ) : (
        <div className="glass-card p-12 text-center text-slate-400 text-xs">
          Select an employee above to inspect their performance scorecard.
        </div>
      )}

      {/* Edit Score Modal */}
      <Modal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} title="Update Performance Scores">
        <form onSubmit={handleUpdateScores} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Task Completion Score (0-100)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={scoreForm.taskCompletionScore}
                onChange={(e) => setScoreForm({ ...scoreForm, taskCompletionScore: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Attendance Score (0-100)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={scoreForm.attendanceScore}
                onChange={(e) => setScoreForm({ ...scoreForm, attendanceScore: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">On-Time Delivery (0-100)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={scoreForm.onTimeDeliveryScore}
                onChange={(e) => setScoreForm({ ...scoreForm, onTimeDeliveryScore: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Productivity Score (0-100)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={scoreForm.productivityScore}
                onChange={(e) => setScoreForm({ ...scoreForm, productivityScore: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Manager Feedback Notes</label>
            <textarea
              rows={3}
              value={scoreForm.managerFeedback}
              onChange={(e) => setScoreForm({ ...scoreForm, managerFeedback: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
            ></textarea>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors"
          >
            {submitting ? 'Saving Scores...' : 'Recalculate Weighted Overall Score'}
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default PerformanceDashboard;
