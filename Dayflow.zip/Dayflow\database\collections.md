# Dayflow - Database Collections Documentation

This document describes the 6 MongoDB collections used in Dayflow, their field specifications, data types, required constraints, and relationships.

---

## 1. `users` Collection

Stores authentication credentials, security parameters, role assignments, and login status.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `_id` | ObjectId | Yes | Unique identifier |
| `employeeId` | String | Yes | Auto-generated Employee ID (e.g. `OT-JODO-2023-0001`) |
| `email` | String | Yes | Unique login email address |
| `password` | String | Yes | bcrypt hashed password |
| `role` | String | Yes | User authorization role: `ADMIN`, `HR`, or `EMPLOYEE` |
| `isFirstLogin` | Boolean | Default: `true` | Flag to prompt initial password change |
| `isActive` | Boolean | Default: `true` | Account active flag |
| `createdAt` | Date | Auto | Record creation timestamp |
| `updatedAt` | Date | Auto | Record last update timestamp |

---

## 2. `employees` Collection

Stores detailed personnel profiles, personal info, job details, and salary components.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `_id` | ObjectId | Yes | Unique identifier |
| `userId` | ObjectId (Ref: User) | Yes | Reference to User document |
| `employeeId` | String | Yes | Auto-generated Employee ID |
| `firstName` | String | Yes | First name |
| `lastName` | String | Yes | Last name |
| `email` | String | Yes | Contact email |
| `phone` | String | Yes | Phone number |
| `profileImage` | String | No | URL to profile avatar |
| `company` | String | Yes | Company / Organization name |
| `department` | String | Yes | Department (e.g. Engineering, Sales, HR) |
| `jobPosition` | String | Yes | Job title / position |
| `manager` | String | No | Direct supervisor name |
| `location` | String | No | Work location / office city |
| `dateOfBirth` | Date | No | Date of birth |
| `joiningDate` | Date | Yes | Employment start date |
| `skills` | [String] | No | Array of technical/soft skills |
| `salary` | Object | No | **Restricted Admin Only** salary object (wageType, monthlyWage, basicSalary, HRA, etc.) |

---

## 3. `tasks` Collection

Stores workload items, priority levels, status workflows, assignment tracking, and comments.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `_id` | ObjectId | Yes | Unique task ID |
| `title` | String | Yes | Task title |
| `description` | String | Yes | Detailed description |
| `assignedTo` | ObjectId (Ref: Employee) | Yes | Employee assigned to this task |
| `createdBy` | ObjectId (Ref: User) | Yes | Admin/Manager who created task |
| `priority` | String | Yes | `LOW`, `MEDIUM`, `HIGH`, `URGENT` |
| `status` | String | Yes | `TODO`, `IN_PROGRESS`, `REVIEW`, `COMPLETED`, `OVERDUE` |
| `dueDate` | Date | Yes | Deadline date |
| `progress` | Number | Default: 0 | Progress percentage (0-100) |
| `comments` | [Object] | No | Nested comment log with author and timestamp |

---

## 4. `attendance` Collection

Tracks daily check-in / check-out timestamps, calculated work hours, and status.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `_id` | ObjectId | Yes | Unique record ID |
| `employeeId` | ObjectId (Ref: Employee) | Yes | Employee reference |
| `date` | Date | Yes | Calendar date (YYYY-MM-DD) |
| `checkIn` | Date | No | Check-in timestamp |
| `checkOut` | Date | No | Check-out timestamp |
| `workHours` | Number | Default: 0 | Duration worked in hours |
| `extraHours` | Number | Default: 0 | Overtime hours |
| `status` | String | Yes | `PRESENT`, `ABSENT`, `LATE`, `ON_LEAVE` |

---

## 5. `leaves` Collection

Manages leave applications, time-off types, duration calculation, and approval flows.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `_id` | ObjectId | Yes | Unique leave request ID |
| `employeeId` | ObjectId (Ref: Employee) | Yes | Employee applicant |
| `leaveType` | String | Yes | `Paid Time Off`, `Sick Leave`, `Unpaid Leave` |
| `startDate` | Date | Yes | Leave start date |
| `endDate` | Date | Yes | Leave end date |
| `numberOfDays` | Number | Yes | Total days requested |
| `reason` | String | Yes | Justification for time off |
| `status` | String | Default: `PENDING` | `PENDING`, `APPROVED`, `REJECTED` |

---

## 6. `performance` Collection

Stores quarterly evaluation metrics, weighted scores, feedback, and Gemini AI insights.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `_id` | ObjectId | Yes | Unique performance document ID |
| `employeeId` | ObjectId (Ref: Employee) | Yes | Target employee |
| `taskCompletionScore` | Number | Yes | 0-100 score (40% weight) |
| `attendanceScore` | Number | Yes | 0-100 score (20% weight) |
| `onTimeDeliveryScore` | Number | Yes | 0-100 score (20% weight) |
| `productivityScore` | Number | Yes | 0-100 score (20% weight) |
| `overallScore` | Number | Auto | Weighted average score |
| `strengths` | [String] | No | Highlighted strengths |
| `weaknesses` | [String] | No | Areas for growth |
| `suggestions` | [String] | No | Actionable tips |
| `managerFeedback` | String | No | Qualitative supervisor review |
| `aiInsights` | Object | No | Generated Gemini AI analysis object |
| `reviewPeriod` | String | Yes | E.g., `Q3 2026` |
