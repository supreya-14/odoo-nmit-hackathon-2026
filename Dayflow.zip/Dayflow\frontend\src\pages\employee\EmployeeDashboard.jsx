import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import StatusBadge from '../../components/StatusBadge';
import LoadingSpinner from '../../components/LoadingSpinner';
import { attendanceService } from '../../services/attendanceService';
import { taskService } from '../../services/taskService';
import { leaveService } from '../../services/leaveService';
import { performanceService } from '../../services/performanceService';
import {
  CheckCircle2,
  Clock,
  Calendar,
  Award,
  ArrowUpRight,
  Sparkles,
  Play,
  Square,
  AlertCircle,
} from 'lucide-react';
import { Link } from 'react-router-dom';

const EmployeeDashboard = () => {
  const { user, employee } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [leaveBalance, setLeaveBalance] = useState({ ptoRemaining: 15, sickRemaining: 10 });
  const [performance, setPerformance] = useState(null);
  const [todayAttendance, setTodayAttendance] = useState(null);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [toast, setToast] = useState('');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Timer effect when checked in
  useEffect(() => {
    let interval = null;
    if (todayAttendance && todayAttendance.checkIn && !todayAttendance.checkOut) {
      const startTime = new Date(todayAttendance.checkIn).getTime();
      interval = setInterval(() => {
        const now = new Date().getTime();
        setTimerSeconds(Math.floor((now - startTime) / 1000));
      }, 1000);
    } else {
      setTimerSeconds(0);
    }
    return () => clearInterval(interval);
  }, [todayAttendance]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [taskRes, attRes, leaveRes, perfRes] = await Promise.allSettled([
        taskService.getAll(),
        attendanceService.getMyAttendance(),
        leaveService.getMyLeaves(),
        performanceService.getMyPerformance(),
      ]);

      if (taskRes.status === 'fulfilled') setTasks(taskRes.value || []);
      if (attRes.status === 'fulfilled') {
        const attList = attRes.value || [];
        setAttendance(attList);
        const today = new Date().toISOString().split('T')[0];
        const record = attList.find((r) => r.date && r.date.startsWith(today));
        setTodayAttendance(record || null);
      }
      if (leaveRes.status === 'fulfilled') {
        setLeaveBalance(leaveRes.value?.leaveBalance || { ptoRemaining: 15, sickRemaining: 10 });
      }
      if (perfRes.status === 'fulfilled') setPerformance(perfRes.value);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    try {
      setActionLoading(true);
      const record = await attendanceService.checkIn();
      setTodayAttendance(record);
      setToast('Successfully checked in for today!');
    } catch (err) {
      setToast(err.response?.data?.message || 'Check-in failed');
    } finally {
      setActionLoading(false);
      setTimeout(() => setToast(''), 4000);
    }
  };

  const handleCheckOut = async () => {
    try {
      setActionLoading(true);
      const record = await attendanceService.checkOut();
      setTodayAttendance(record);
      setToast('Successfully checked out. Great work today!');
    } catch (err) {
      setToast(err.response?.data?.message || 'Check-out failed');
    } finally {
      setActionLoading(false);
      setTimeout(() => setToast(''), 4000);
    }
  };

  const formatTimer = (totalSecs) => {
    const hrs = String(Math.floor(totalSecs / 3600)).padStart(2, '0');
    const mins = String(Math.floor((totalSecs % 3600) / 60)).padStart(2, '0');
    const secs = String(totalSecs % 60).padStart(2, '0');
    return `${hrs}:${mins}:${secs}`;
  };

  if (loading) return <LoadingSpinner label="Loading your employee portal..." />;

  const completedTasksCount = tasks.filter((t) => t.status === 'COMPLETED').length;
  const pendingTasksCount = tasks.filter((t) => t.status !== 'COMPLETED').length;
  const attendanceStatus = todayAttendance ? todayAttendance.status : 'ABSENT';

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Toast Notification */}
      {toast && (
        <div className="p-4 rounded-xl bg-indigo-600/90 text-white font-semibold text-sm shadow-xl flex items-center justify-between">
          <span>{toast}</span>
          <button onClick={() => setToast('')} className="text-xs underline ml-4">
            Dismiss
          </button>
        </div>
      )}

      {/* Welcome Hero Banner with Dayflow Signature Flow Element */}
      <div className="glass-card p-6 md:p-8 bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-slate-900 border-indigo-500/30 relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center font-extrabold text-white text-2xl shadow-xl shadow-indigo-600/30">
              {employee?.firstName?.charAt(0) || user?.email?.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs uppercase tracking-widest font-bold text-indigo-400">Employee Workspace</span>
                <StatusBadge status={attendanceStatus} />
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-white">
                Welcome back, {employee ? `${employee.firstName} ${employee.lastName}` : 'Team Member'}!
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {employee?.jobPosition || 'Employee'} • {employee?.department || 'Department'} • ID: {user?.employeeId}
              </p>
            </div>
          </div>

          {/* Live Check-In / Check-Out Widget */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 flex items-center gap-4 shadow-xl">
            {todayAttendance?.checkIn && !todayAttendance?.checkOut ? (
              <div className="flex items-center gap-4">
                <div className="text-left">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Live Shift Timer</span>
                  <span className="text-xl font-mono font-bold text-emerald-400">{formatTimer(timerSeconds)}</span>
                </div>
                <button
                  onClick={handleCheckOut}
                  disabled={actionLoading}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs shadow-lg shadow-rose-600/20 transition-all"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Check Out</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <div className="text-left">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Attendance Status</span>
                  <span className="text-sm font-semibold text-slate-200">
                    {todayAttendance?.checkOut ? 'Shift Completed' : 'Not Checked In Yet'}
                  </span>
                </div>
                {!todayAttendance?.checkOut && (
                  <button
                    onClick={handleCheckIn}
                    disabled={actionLoading}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-lg shadow-emerald-600/20 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Check In Now</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Pending Tasks</span>
            <Clock className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">{pendingTasksCount}</div>
          <span className="text-[11px] text-slate-500 block mt-1">Requires your attention</span>
        </div>

        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Completed Tasks</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-400">{completedTasksCount}</div>
          <span className="text-[11px] text-slate-500 block mt-1">Total tasks finished</span>
        </div>

        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Performance Score</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-amber-400">
            {performance ? `${performance.overallScore}%` : '88%'}
          </div>
          <span className="text-[11px] text-slate-500 block mt-1">Weighted productivity score</span>
        </div>

        <div className="glass-card p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>PTO Leave Balance</span>
            <Calendar className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-extrabold text-purple-300">{leaveBalance.ptoRemaining} Days</div>
          <span className="text-[11px] text-slate-500 block mt-1">15 days standard allowance</span>
        </div>
      </div>

      {/* Main Grid: My Assigned Tasks Preview + Recent Attendance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Priority Tasks */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span>My Assigned Tasks</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-indigo-400 font-semibold">
                {tasks.length}
              </span>
            </h3>
            <Link to="/my-tasks" className="text-xs text-indigo-400 hover:underline font-semibold flex items-center gap-1">
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {tasks.length === 0 ? (
            <div className="glass-card p-8 text-center text-slate-400 text-xs">
              No tasks currently assigned. Relax or check with your project lead!
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tasks.slice(0, 4).map((t) => (
                <div key={t._id} className="glass-card p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] uppercase font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-md">
                        {t.priority} Priority
                      </span>
                      <StatusBadge status={t.status} />
                    </div>
                    <h4 className="font-semibold text-white text-sm line-clamp-1">{t.title}</h4>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1">{t.description}</p>
                  </div>
                  <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Progress: {t.progress}%</span>
                    <Link to="/my-tasks" className="text-indigo-400 hover:underline">Update →</Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Col: Performance & Quick Actions */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-white">Performance Overview</h3>
          <div className="glass-card p-5 space-y-4">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <div>
                <h4 className="font-semibold text-white text-sm">Efficiency Index</h4>
                <p className="text-xs text-slate-400">Q3 Performance Breakdown</p>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Task Velocity</span>
                  <span className="font-bold text-indigo-300">{performance?.taskCompletionScore || 90}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-500 h-full rounded-full"
                    style={{ width: `${performance?.taskCompletionScore || 90}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Attendance & Punctuality</span>
                  <span className="font-bold text-emerald-400">{performance?.attendanceScore || 95}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-400 h-full rounded-full"
                    style={{ width: `${performance?.attendanceScore || 95}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <Link
              to="/my-performance"
              className="w-full block text-center py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
            >
              View Full Performance Scorecard
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeDashboard;
