import React, { useState, useEffect } from 'react';
import PerformanceCard from '../../components/PerformanceCard';
import LoadingSpinner from '../../components/LoadingSpinner';
import { performanceService } from '../../services/performanceService';
import { TrendingUp, Sparkles } from 'lucide-react';

const MyPerformance = () => {
  const [performance, setPerformance] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPerformance();
  }, []);

  const fetchPerformance = async () => {
    try {
      setLoading(true);
      const data = await performanceService.getMyPerformance();
      setPerformance(data);
    } catch (err) {
      console.error('Error fetching performance:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner label="Calculating performance scores & AI insights..." />;

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-indigo-400" /> My Performance Scorecard
        </h2>
        <p className="text-xs text-slate-400">Quarterly weighted productivity score, manager reviews, and AI insights</p>
      </div>

      <PerformanceCard performance={performance} />
    </div>
  );
};

export default MyPerformance;
