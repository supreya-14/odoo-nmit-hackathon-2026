import React from 'react';
import { Award, Sparkles, CheckCircle2, Target } from 'lucide-react';

const PerformanceCard = ({ performance, onGenerateAi, isGeneratingAi = false, isAdmin = false }) => {
  if (!performance) return null;

  const {
    taskCompletionScore = 0,
    attendanceScore = 0,
    onTimeDeliveryScore = 0,
    productivityScore = 0,
    overallScore = 0,
    managerFeedback = '',
    aiInsights = null,
    reviewPeriod = 'Q3 2026',
  } = performance;

  return (
    <div className="space-y-6">
      {/* Overall Score Banner - Perfectly Aligned */}
      <div className="glass-card p-6 md:p-8 bg-gradient-to-r from-indigo-950/40 via-purple-950/30 to-slate-900 border-indigo-500/30 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-5">
            {/* Perfectly Aligned Score Badge Box */}
            <div className="px-5 py-4 min-w-[6.5rem] h-20 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center font-extrabold text-white text-2xl sm:text-3xl shadow-xl shadow-indigo-600/30 shrink-0 text-center tracking-tight leading-none border border-indigo-400/30">
              {overallScore}%
            </div>
            
            <div className="flex flex-col justify-center">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs uppercase font-bold tracking-widest text-indigo-400">Overall Efficiency Score</span>
                <span className="px-2 py-0.5 rounded-md bg-slate-800 text-[10px] text-slate-300 font-semibold">{reviewPeriod}</span>
              </div>
              <h3 className="text-xl font-bold text-white">High Productivity Performance</h3>
              <p className="text-xs text-slate-400 mt-0.5">Calculated using 40% Task + 20% Attendance + 20% Delivery + 20% Velocity</p>
            </div>
          </div>

          {isAdmin && onGenerateAi && (
            <button
              onClick={onGenerateAi}
              disabled={isGeneratingAi}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-xs shadow-lg shadow-indigo-500/25 transition-all transform hover:scale-105 disabled:opacity-50 shrink-0"
            >
              <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
              <span>{isGeneratingAi ? 'Analyzing with Gemini...' : 'Generate Gemini AI Insights'}</span>
            </button>
          )}
        </div>

        {/* 4 Score Meters */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-800/80">
          <div>
            <span className="text-xs text-slate-400 block font-medium">Task Completion (40%)</span>
            <span className="text-lg font-bold text-indigo-300">{taskCompletionScore}%</span>
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Attendance (20%)</span>
            <span className="text-lg font-bold text-emerald-400">{attendanceScore}%</span>
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">On-Time Delivery (20%)</span>
            <span className="text-lg font-bold text-purple-300">{onTimeDeliveryScore}%</span>
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Productivity (20%)</span>
            <span className="text-lg font-bold text-amber-300">{productivityScore}%</span>
          </div>
        </div>
      </div>

      {/* AI Insights Card */}
      {aiInsights && (
        <div className="glass-card p-6 border-indigo-500/30 bg-slate-900/80">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <h4 className="font-semibold text-white text-base">Gemini AI Executive Summary & Recommendations</h4>
          </div>
          <p className="text-sm text-slate-300 italic mb-4 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
            "{aiInsights.summary}"
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {aiInsights.strengths?.length > 0 && (
              <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-800/30">
                <span className="font-bold text-emerald-400 flex items-center gap-1.5 mb-2">
                  <CheckCircle2 className="w-4 h-4" /> Core Strengths
                </span>
                <ul className="space-y-1 text-slate-300">
                  {aiInsights.strengths.map((s, idx) => (
                    <li key={idx}>• {s}</li>
                  ))}
                </ul>
              </div>
            )}

            {aiInsights.recommendedGoals?.length > 0 && (
              <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-800/30">
                <span className="font-bold text-indigo-300 flex items-center gap-1.5 mb-2">
                  <Target className="w-4 h-4" /> Recommended Q4 Goals
                </span>
                <ul className="space-y-1 text-slate-300">
                  {aiInsights.recommendedGoals.map((g, idx) => (
                    <li key={idx}>• {g}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Qualitative Feedback */}
      {managerFeedback && (
        <div className="glass-card p-5">
          <h4 className="font-semibold text-white text-sm mb-2">Manager Feedback</h4>
          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3 rounded-xl border border-slate-800">
            {managerFeedback}
          </p>
        </div>
      )}
    </div>
  );
};

export default PerformanceCard;
