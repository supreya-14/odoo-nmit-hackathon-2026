import React from 'react';
import StatusBadge from './StatusBadge';
import { TASK_PRIORITY } from '../utils/constants';
import { formatDate } from '../utils/formatDate';
import { Calendar, User, MessageSquare } from 'lucide-react';

const TaskCard = ({ task, onUpdateStatus, onClick }) => {
  const { title, description, assignedTo, priority, status, dueDate, progress, comments = [] } = task;

  const priorityObj = TASK_PRIORITY[priority] || TASK_PRIORITY.MEDIUM;
  const assigneeName = assignedTo
    ? `${assignedTo.firstName || ''} ${assignedTo.lastName || ''}`.trim() || assignedTo.employeeId
    : 'Unassigned';

  return (
    <div className="glass-card-hover p-5 flex flex-col justify-between">
      <div>
        {/* Header Badges */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${priorityObj.color}`}>
            {priorityObj.label} Priority
          </span>
          <StatusBadge status={status} />
        </div>

        {/* Title & Description */}
        <h4
          onClick={() => onClick && onClick(task)}
          className="font-semibold text-white text-base hover:text-indigo-400 cursor-pointer transition-colors mb-2 line-clamp-1"
        >
          {title}
        </h4>
        <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">{description}</p>

        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-400 font-medium">Progress</span>
            <span className="text-indigo-400 font-bold">{progress}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Card Footer */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5" title="Assigned Employee">
            <User className="w-3.5 h-3.5 text-indigo-400" />
            <span className="truncate max-w-[100px] text-slate-300 font-medium">{assigneeName}</span>
          </div>
          <div className="flex items-center gap-1.5" title="Due Date">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span>{formatDate(dueDate)}</span>
          </div>
        </div>

        {comments.length > 0 && (
          <div className="flex items-center gap-1 text-slate-500">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{comments.length}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskCard;
