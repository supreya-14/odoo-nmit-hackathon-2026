import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import LoadingSpinner from '../../components/LoadingSpinner';
import StatusBadge from '../../components/StatusBadge';
import { employeeService } from '../../services/employeeService';
import { performanceService } from '../../services/performanceService';
import { formatCurrency, formatDate } from '../../utils/formatDate';
import { ArrowLeft, Mail, Phone, MapPin, DollarSign, Shield, Award, Calendar, Trash2 } from 'lucide-react';

const EmployeeDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState(null);
  const [performance, setPerformance] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDetails();
  }, [id]);

  const fetchDetails = async () => {
    try {
      setLoading(true);
      const empData = await employeeService.getById(id);
      setEmployee(empData);

      if (empData) {
        const perfData = await performanceService.getByEmployeeId(empData._id);
        setPerformance(perfData);
      }
    } catch (err) {
      console.error('Error fetching employee details:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this employee record?')) return;
    try {
      await employeeService.delete(id);
      navigate('/admin/employees');
    } catch (err) {
      alert('Failed to delete employee record');
    }
  };

  if (loading) return <LoadingSpinner label="Loading employee comprehensive details..." />;

  if (!employee) {
    return (
      <div className="glass-card p-12 text-center text-slate-400 text-xs">
        Employee record not found.
      </div>
    );
  }

  const fullName = `${employee.firstName} ${employee.lastName}`;
  const salary = employee.salary || {};

  return (
    <div className="space-y-6 animate-fadeIn max-w-5xl mx-auto">
      <button
        onClick={() => navigate('/admin/employees')}
        className="flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Employee Directory
      </button>

      {/* Header Profile Hero Card */}
      <div className="glass-card p-6 md:p-8 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-indigo-500/30">
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center font-extrabold text-white text-3xl shadow-xl">
              {fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-2xl font-bold text-white">{fullName}</h2>
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-semibold">
                  {employee.employeeId}
                </span>
              </div>
              <p className="text-xs text-indigo-400 font-semibold mt-0.5">{employee.jobPosition}</p>
              <p className="text-xs text-slate-400 mt-1">
                Department: {employee.department} • Joining Date: {formatDate(employee.joiningDate)}
              </p>
            </div>
          </div>

          <button
            onClick={handleDelete}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 text-xs font-semibold border border-rose-500/30 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete Employee</span>
          </button>
        </div>
      </div>

      {/* Salary & Compensation Module (Admin/HR Only) */}
      <div className="glass-card p-6 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="text-base font-bold text-white">Salary & Compensation Module</h3>
              <p className="text-xs text-slate-400">Automated calculation breakdown • Restricted to Admin / HR</p>
            </div>
          </div>
          <span className="text-lg font-extrabold text-emerald-400">
            {formatCurrency(salary.monthlyWage || 60000)} / month
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-1">Basic Salary (50%)</span>
            <span className="text-sm font-bold text-white">{formatCurrency(salary.basicSalary || 30000)}</span>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-1">House Rent Allowance</span>
            <span className="text-sm font-bold text-white">{formatCurrency(salary.hra || 15000)}</span>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-1">Standard Allowance</span>
            <span className="text-sm font-bold text-white">{formatCurrency(salary.standardAllowance || 6000)}</span>
          </div>
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-slate-400 block mb-1">Performance Bonus</span>
            <span className="text-sm font-bold text-white">{formatCurrency(salary.performanceBonus || 6000)}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-2">
          <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-800/30">
            <span className="text-slate-400 block">LTA Allowance</span>
            <span className="font-bold text-indigo-300">{formatCurrency(salary.lta || 3000)}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-800/30">
            <span className="text-slate-400 block">Provident Fund (PF)</span>
            <span className="font-bold text-indigo-300">{formatCurrency(salary.providentFund || 3600)}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-indigo-950/20 border border-indigo-800/30">
            <span className="text-slate-400 block">Professional Tax</span>
            <span className="font-bold text-indigo-300">₹{salary.professionalTax || 200}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeDetails;
