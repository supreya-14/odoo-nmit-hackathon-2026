const Employee = require('../models/Employee');
const User = require('../models/User');
const generateEmployeeId = require('../utils/generateEmployeeId');

// @desc    Get all employees
// @route   GET /api/employees
// @access  Private
const getEmployees = async (req, res) => {
  try {
    const employees = await Employee.find().populate('userId', 'role email isActive');

    // Filter salary info for non-admin requests
    const sanitized = employees.map((emp) => {
      const empObj = emp.toObject();
      if (req.user.role === 'EMPLOYEE') {
        delete empObj.salary;
      }
      return empObj;
    });

    res.json(sanitized);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single employee by ID
// @route   GET /api/employees/:id
// @access  Private
const getEmployeeById = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id).populate('userId', 'role email isActive');
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const empObj = employee.toObject();

    // Salary Privacy Rule: Only ADMIN or HR or the employee themselves if authorized by policy
    // Prompt states: "Salary Info (Admin/HR only)"
    if (req.user.role === 'EMPLOYEE') {
      delete empObj.salary;
    }

    res.json(empObj);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create employee (Admin/HR)
// @route   POST /api/employees
// @access  Private/Admin
const createEmployee = async (req, res) => {
  try {
    const { firstName, lastName, email, phone, department, jobPosition, company, monthlyWage, role } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists with this email' });
    }

    const count = await Employee.countDocuments();
    const employeeId = generateEmployeeId(company || 'OneTech', firstName, lastName, new Date().getFullYear(), count + 1);
    const tempPassword = 'Password@123';

    const user = await User.create({
      employeeId,
      email,
      password: tempPassword,
      role: role || 'EMPLOYEE',
      isFirstLogin: true,
    });

    const wage = Number(monthlyWage) || 50000;
    const basic = wage * 0.5;
    const hra = basic * 0.5;
    const stdAllow = wage * 0.1;
    const bonus = wage * 0.1;
    const lta = wage * 0.05;
    const fixedAllow = Math.max(0, wage - (basic + hra + stdAllow + bonus + lta));
    const pf = basic * 0.12;

    const employee = await Employee.create({
      userId: user._id,
      employeeId,
      firstName,
      lastName,
      email,
      phone: phone || '',
      company: company || 'OneTech Solutions',
      department: department || 'Engineering',
      jobPosition: jobPosition || 'Developer',
      salary: {
        wageType: 'MONTHLY',
        monthlyWage: wage,
        yearlyWage: wage * 12,
        basicSalary: basic,
        hra,
        standardAllowance: stdAllow,
        performanceBonus: bonus,
        lta,
        fixedAllowance: fixedAllow,
        providentFund: pf,
        professionalTax: 200,
        workingDays: 22,
        breakTime: 60,
      },
    });

    res.status(201).json({
      message: 'Employee created successfully',
      employee,
      tempPassword,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update employee profile
// @route   PUT /api/employees/:id
// @access  Private
const updateEmployee = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    // Employees can update personal info; Admins can update all
    const isOwner = req.employee && req.employee._id.toString() === employee._id.toString();
    const isAdmin = req.user.role === 'ADMIN' || req.user.role === 'HR';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: 'Not authorized to update this profile' });
    }

    const { phone, address, skills, certifications, about, interests, location, department, jobPosition, salary } = req.body;

    if (phone !== undefined) employee.phone = phone;
    if (address !== undefined) employee.address = address;
    if (skills !== undefined) employee.skills = skills;
    if (certifications !== undefined) employee.certifications = certifications;
    if (about !== undefined) employee.about = about;
    if (interests !== undefined) employee.interests = interests;
    if (location !== undefined) employee.location = location;

    if (isAdmin) {
      if (department) employee.department = department;
      if (jobPosition) employee.jobPosition = jobPosition;
      if (salary) employee.salary = { ...employee.salary, ...salary };
    }

    const updatedEmployee = await employee.save();
    res.json(updatedEmployee);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete employee (Admin)
// @route   DELETE /api/employees/:id
// @access  Private/Admin
const deleteEmployee = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    await User.findByIdAndDelete(employee.userId);
    await Employee.findByIdAndDelete(req.params.id);

    res.json({ message: 'Employee deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getEmployees,
  getEmployeeById,
  createEmployee,
  updateEmployee,
  deleteEmployee,
};
