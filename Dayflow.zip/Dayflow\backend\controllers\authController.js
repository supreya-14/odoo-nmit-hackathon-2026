const User = require('../models/User');
const Employee = require('../models/Employee');
const generateToken = require('../utils/generateToken');
const generateEmployeeId = require('../utils/generateEmployeeId');

// @desc    Register a new company user / employee
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res) => {
  try {
    const { firstName, lastName, email, password, company, department, jobPosition, role } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists with this email address' });
    }

    const employeeCount = await Employee.countDocuments();
    const employeeId = generateEmployeeId(company || 'OneTech', firstName, lastName, new Date().getFullYear(), employeeCount + 1);

    const user = await User.create({
      employeeId,
      email,
      password,
      role: role || 'EMPLOYEE',
      isFirstLogin: false,
    });

    const employee = await Employee.create({
      userId: user._id,
      employeeId,
      firstName,
      lastName,
      email,
      company: company || 'OneTech Solutions',
      department: department || 'Engineering',
      jobPosition: jobPosition || 'Software Engineer',
      joiningDate: new Date(),
    });

    res.status(201).json({
      _id: user._id,
      employeeId: user.employeeId,
      email: user.email,
      role: user.role,
      employee: {
        _id: employee._id,
        firstName: employee.firstName,
        lastName: employee.lastName,
        department: employee.department,
        jobPosition: employee.jobPosition,
      },
      token: generateToken(user._id, user.role, user.employeeId),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Auth user & get token
// @route   POST /api/auth/login
// @access  Public
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (user && (await user.matchPassword(password))) {
      const employee = await Employee.findOne({ userId: user._id });

      res.json({
        _id: user._id,
        employeeId: user.employeeId,
        email: user.email,
        role: user.role,
        isFirstLogin: user.isFirstLogin,
        employee,
        token: generateToken(user._id, user.role, user.employeeId),
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get current user profile
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    const employee = await Employee.findOne({ userId: user._id });

    // Exclude sensitive salary details if role is EMPLOYEE viewing self
    if (user.role === 'EMPLOYEE' && employee) {
      employee.salary = undefined;
    }

    res.json({
      user,
      employee,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
// @access  Private
const logoutUser = async (req, res) => {
  res.json({ message: 'Logged out successfully' });
};

module.exports = {
  registerUser,
  loginUser,
  getMe,
  logoutUser,
};
