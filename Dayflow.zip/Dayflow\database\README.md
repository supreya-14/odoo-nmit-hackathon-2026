# Dayflow - Database Setup & Documentation

This folder contains database documentation, collection schemas, relationships, and realistic sample data for the **Dayflow** Smart Employee Performance & Task Management System.

## MongoDB Setup Options

### 1. MongoDB Atlas (Cloud - Recommended)
1. Sign in to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).
2. Create a Cluster (M0 Free Tier).
3. Under **Database Access**, create a database user with read/write access.
4. Under **Network Access**, whitelist your IP address or add `0.0.0.0/0` for development access.
5. Obtain the Connection String (`mongodb+srv://...`) and paste it into `backend/.env` under `MONGODB_URI`.

### 2. Local MongoDB Instance
Alternatively, run MongoDB locally on port 27017:
`MONGODB_URI=mongodb://localhost:27017/dayflow`

---

## Seeding Demo Data

To populate your database with realistic demo users, employees, tasks, attendance, leave requests, and performance records:

```bash
cd backend
npm run seed
```

This runs `backend/database/seed.js` using Mongoose, automatically populating all 6 collections.

---

## Collection Documentation
Refer to [collections.md](./collections.md) for full schema definitions, field types, validation rules, and sample JSON payloads.

---

## Folder Structure
```
database/
├── README.md
├── collections.md
└── sample-data/
    ├── users.json
    ├── employees.json
    ├── tasks.json
    ├── attendance.json
    ├── leaves.json
    └── performance.json
```
