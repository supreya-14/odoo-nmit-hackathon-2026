import React from 'react';
import StatusBadge from './StatusBadge';
import { formatDate, formatTime } from '../utils/formatDate';
import { Clock, Calendar } from 'lucide-react';

const AttendanceCard = ({ record }) => {
  const { date, checkIn, checkOut, workHours = 0, status = 'PRESENT' } = record;

  return (
    <div className="glass-card p-4 flex flex-col justify-between">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 dark:text-slate-300 light:text-slate-700">
          <Calendar className="w-4 h-4 text-indigo-500" />
          <span>{formatDate(date)}</span>
        </div>
        <StatusBadge status={status} />
      </div>

      <div className="grid grid-cols-2 gap-3 my-2 bg-slate-950/40 dark:bg-slate-950/40 light:bg-slate-50 p-3 rounded-xl border border-slate-800/60 dark:border-slate-800/60 light:border-slate-200">
        <div>
          <span className="text-[11px] text-slate-400 dark:text-slate-500 light:text-slate-500 block uppercase font-medium">
            Check In
          </span>
          <span className="text-sm font-semibold text-emerald-400 dark:text-emerald-400 light:text-emerald-600">
            {formatTime(checkIn)}
          </span>
        </div>
        <div>
          <span className="text-[11px] text-slate-400 dark:text-slate-500 light:text-slate-500 block uppercase font-medium">
            Check Out
          </span>
          <span className="text-sm font-semibold text-indigo-400 dark:text-indigo-400 light:text-indigo-600">
            {formatTime(checkOut)}
          </span>
        </div>
      </div>

      <div className="pt-2 flex items-center justify-between text-xs text-slate-400 dark:text-slate-400 light:text-slate-600">
        <div className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>Hours Worked:</span>
        </div>
        <span className="font-bold text-slate-100 dark:text-slate-100 light:text-slate-900">{workHours} hrs</span>
      </div>
    </div>
  );
};

export default AttendanceCard;
