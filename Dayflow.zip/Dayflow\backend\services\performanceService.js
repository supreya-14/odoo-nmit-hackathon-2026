const Performance = require('../models/Performance');

const calculateWeightedScore = (taskScore, attendanceScore, onTimeScore, productivityScore) => {
  return Number(
    (
      taskScore * 0.4 +
      attendanceScore * 0.2 +
      onTimeScore * 0.2 +
      productivityScore * 0.2
    ).toFixed(1)
  );
};

module.exports = { calculateWeightedScore };
