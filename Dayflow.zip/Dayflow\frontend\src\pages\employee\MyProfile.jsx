import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { employeeService } from '../../services/employeeService';
import { formatCurrency, formatDate } from '../../utils/formatDate';
import {
  User,
  Mail,
  Phone,
  Building,
  MapPin,
  FileText,
  Shield,
  DollarSign,
  Key,
  Edit2,
  Check,
  AlertTriangle,
} from 'lucide-react';

const MyProfile = () => {
  const { user, employee, isAdmin, fetchCurrentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('resume');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    phone: employee?.phone || '',
    address: employee?.address || '',
    location: employee?.location || '',
    skills: employee?.skills?.join(', ') || '',
    certifications: employee?.certifications?.join(', ') || '',
    about: employee?.about || '',
    interests: employee?.interests?.join(', ') || '',
  });

  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const handleSave = async (e) => {
    e.preventDefault();
    if (!employee) return;
    setSaving(true);
    setMessage('');

    try {
      const skillsArray = formData.skills.split(',').map((s) => s.trim()).filter(Boolean);
      const certsArray = formData.certifications.split(',').map((s) => s.trim()).filter(Boolean);
      const interestsArray = formData.interests.split(',').map((s) => s.trim()).filter(Boolean);

      await employeeService.update(employee._id, {
        phone: formData.phone,
        address: formData.address,
        location: formData.location,
        skills: skillsArray,
        certifications: certsArray,
        about: formData.about,
        interests: interestsArray,
      });

      await fetchCurrentUser();
      setIsEditing(false);
      setMessage('Profile updated successfully!');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to update profile');
    } finally {
      setSaving(false);
      setTimeout(() => setMessage(''), 4000);
    }
  };

  const fullName = employee ? `${employee.firstName} ${employee.lastName}` : user?.email || 'User';

  return (
    <div className="space-y-8 animate-fadeIn max-w-5xl mx-auto">
      {message && (
        <div className="p-4 rounded-xl bg-indigo-600/90 text-white font-semibold text-sm shadow-xl flex items-center justify-between">
          <span>{message}</span>
          <button onClick={() => setMessage('')} className="text-xs underline ml-4">
            Dismiss
          </button>
        </div>
      )}

      {/* Header Profile Hero Card */}
      <div className="glass-card p-6 md:p-8 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-indigo-500/30">
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center font-extrabold text-white text-3xl shadow-xl shadow-indigo-600/30">
              {fullName.charAt(0).toUpperCase()}
            </div>
            <div className="text-center md:text-left">
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-1">
                <h2 className="text-2xl font-bold text-white">{fullName}</h2>
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-semibold">
                  {user?.employeeId}
                </span>
              </div>
              <p className="text-sm font-semibold text-indigo-400">{employee?.jobPosition || 'Employee'}</p>
              <p className="text-xs text-slate-400 mt-1">
                {employee?.department} • {employee?.company} • Manager: {employee?.manager || 'HR Team'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>{isEditing ? 'Cancel Editing' : 'Edit Profile'}</span>
          </button>
        </div>

        {/* Contact Info Chips */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-800 text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-indigo-400" />
            <span className="truncate">{user?.email}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-emerald-400" />
            <span>{employee?.phone || 'Not provided'}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-amber-400" />
            <span>{employee?.location || 'Headquarters'}</span>
          </div>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex border-b border-slate-800 gap-4 text-sm font-semibold overflow-x-auto">
        <button
          onClick={() => setActiveTab('resume')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'resume' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Resume & Skills</span>
        </button>

        <button
          onClick={() => setActiveTab('private')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'private' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Private Info</span>
        </button>

        {/* Salary Tab Only Visible to Admin / HR */}
        {isAdmin && (
          <button
            onClick={() => setActiveTab('salary')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'salary' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <span>Salary Info (Admin/HR Only)</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('security')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'security' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>Security</span>
        </button>
      </div>

      {/* Editable Form Wrap */}
      {isEditing ? (
        <form onSubmit={handleSave} className="glass-card p-6 space-y-4">
          <h3 className="text-base font-bold text-white mb-4">Edit Profile Information</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Location</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Skills (comma separated)</label>
            <input
              type="text"
              value={formData.skills}
              onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">About Me</label>
            <textarea
              rows={3}
              value={formData.about}
              onChange={(e) => setFormData({ ...formData, about: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
            ></textarea>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors"
          >
            {saving ? 'Saving...' : 'Save Profile Changes'}
          </button>
        </form>
      ) : (
        <>
          {/* Tab 1: Resume */}
          {activeTab === 'resume' && (
            <div className="space-y-6">
              <div className="glass-card p-6 space-y-4">
                <h3 className="text-base font-bold text-white">About</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {employee?.about || 'No bio provided yet. Click Edit Profile to add your background summary.'}
                </p>
              </div>

              <div className="glass-card p-6 space-y-4">
                <h3 className="text-base font-bold text-white">Technical Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {employee?.skills?.length > 0 ? (
                    employee.skills.map((skill, idx) => (
                      <span key={idx} className="px-3 py-1 rounded-xl bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-semibold">
                        {skill}
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-slate-500">No skills listed yet.</span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Private Info */}
          {activeTab === 'private' && (
            <div className="glass-card p-6 space-y-4 text-xs">
              <h3 className="text-base font-bold text-white mb-4">Personal & Contact Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block">Joining Date</span>
                  <span className="font-semibold text-slate-200">{formatDate(employee?.joiningDate)}</span>
                </div>
                <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block">Nationality</span>
                  <span className="font-semibold text-slate-200">{employee?.nationality || 'American'}</span>
                </div>
                <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block">Gender</span>
                  <span className="font-semibold text-slate-200">{employee?.gender || 'Prefer Not to Say'}</span>
                </div>
                <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block">Marital Status</span>
                  <span className="font-semibold text-slate-200">{employee?.maritalStatus || 'Single'}</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Salary Info (Admin/HR Only) */}
          {activeTab === 'salary' && isAdmin && (
            <div className="glass-card p-6 space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h3 className="text-base font-bold text-white">Compensation Breakdown</h3>
                  <p className="text-xs text-slate-400">Restricted Admin View • Monthly Compensation</p>
                </div>
                <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 font-extrabold text-sm border border-emerald-500/20">
                  {formatCurrency(employee?.salary?.monthlyWage || 60000)} / mo
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-400 block mb-1">Basic Salary (50%)</span>
                  <span className="text-base font-bold text-white">{formatCurrency(employee?.salary?.basicSalary || 30000)}</span>
                </div>
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-400 block mb-1">HRA (50% Basic)</span>
                  <span className="text-base font-bold text-white">{formatCurrency(employee?.salary?.hra || 15000)}</span>
                </div>
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <span className="text-slate-400 block mb-1">Performance Bonus</span>
                  <span className="text-base font-bold text-white">{formatCurrency(employee?.salary?.performanceBonus || 6000)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 4: Security */}
          {activeTab === 'security' && (
            <div className="glass-card p-6 space-y-4">
              <h3 className="text-base font-bold text-white">Security Settings</h3>
              <p className="text-xs text-slate-400">Account status is active and verified under Employee ID {user?.employeeId}.</p>
              <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-800/30 text-xs text-slate-300">
                <span>Password last changed: Active session. Contact HR to request password reset if needed.</span>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default MyProfile;
