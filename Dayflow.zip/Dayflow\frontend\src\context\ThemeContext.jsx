import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [isDark, setIsDark] = useState(() => {
    const saved = localStorage.getItem('dayflow_theme');
    return saved ? saved === 'dark' : true;
  });

  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;

    if (isDark) {
      root.classList.add('dark');
      root.classList.remove('light');
      body.classList.add('bg-slate-950', 'text-slate-100');
      body.classList.remove('bg-slate-50', 'text-slate-900');
      localStorage.setItem('dayflow_theme', 'dark');
    } else {
      root.classList.remove('dark');
      root.classList.add('light');
      body.classList.add('bg-slate-50', 'text-slate-900');
      body.classList.remove('bg-slate-950', 'text-slate-100');
      localStorage.setItem('dayflow_theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark((prev) => !prev);

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
