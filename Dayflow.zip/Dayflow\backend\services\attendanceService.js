const Attendance = require('../models/Attendance');

const getTodayAttendanceStats = async () => {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  const todayRecords = await Attendance.find({
    date: { $gte: startOfDay, $lte: endOfDay },
  });

  const present = todayRecords.filter((r) => r.status === 'PRESENT' || r.status === 'LATE').length;
  const onLeave = todayRecords.filter((r) => r.status === 'ON_LEAVE').length;
  const absent = todayRecords.filter((r) => r.status === 'ABSENT').length;

  return { present, onLeave, absent, totalTodayLogged: todayRecords.length };
};

module.exports = { getTodayAttendanceStats };
