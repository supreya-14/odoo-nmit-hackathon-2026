import api from './api';

export const attendanceService = {
  checkIn: async () => {
    const res = await api.post('/attendance/check-in');
    return res.data;
  },
  checkOut: async () => {
    const res = await api.post('/attendance/check-out');
    return res.data;
  },
  getMyAttendance: async () => {
    const res = await api.get('/attendance/my');
    return res.data;
  },
  getAllAttendance: async () => {
    const res = await api.get('/attendance/all');
    return res.data;
  },
};
