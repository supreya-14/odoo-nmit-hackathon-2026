import React, { useState, useEffect } from 'react';
import LeaveCard from '../../components/LeaveCard';
import LoadingSpinner from '../../components/LoadingSpinner';
import { leaveService } from '../../services/leaveService';
import { CalendarDays, Filter } from 'lucide-react';

const LeaveManagement = () => {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('PENDING');

  useEffect(() => {
    fetchLeaves();
  }, []);

  const fetchLeaves = async () => {
    try {
      setLoading(true);
      const data = await leaveService.getAllLeaves();
      setLeaves(data || []);
    } catch (err) {
      console.error('Failed to fetch leaves:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id) => {
    try {
      await leaveService.approve(id);
      fetchLeaves();
    } catch (err) {
      alert('Failed to approve leave');
    }
  };

  const handleReject = async (id) => {
    const reason = window.prompt('Enter rejection reason for employee:');
    if (reason === null) return;
    try {
      await leaveService.reject(id, reason);
      fetchLeaves();
    } catch (err) {
      alert('Failed to reject leave');
    }
  };

  if (loading) return <LoadingSpinner label="Loading employee leave requests..." />;

  const filteredLeaves = leaves.filter((l) => {
    if (filterStatus === 'ALL') return true;
    return l.status === filterStatus;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-indigo-400" /> Leave Request Management
          </h2>
          <p className="text-xs text-slate-400">Review time-off applications, approve PTO, or reject with reason</p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
          <Filter className="w-4 h-4 text-slate-500 ml-2" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-transparent text-xs text-slate-200 focus:outline-none pr-2 cursor-pointer font-medium"
          >
            <option value="PENDING" className="bg-slate-900">Pending Approval</option>
            <option value="APPROVED" className="bg-slate-900">Approved</option>
            <option value="REJECTED" className="bg-slate-900">Rejected</option>
            <option value="ALL" className="bg-slate-900">All Requests</option>
          </select>
        </div>
      </div>

      {filteredLeaves.length === 0 ? (
        <div className="glass-card p-12 text-center text-slate-400 text-xs">
          No leave requests found under selected filter.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredLeaves.map((l) => (
            <LeaveCard
              key={l._id}
              leave={l}
              isAdmin={true}
              onApprove={handleApprove}
              onReject={handleReject}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default LeaveManagement;
