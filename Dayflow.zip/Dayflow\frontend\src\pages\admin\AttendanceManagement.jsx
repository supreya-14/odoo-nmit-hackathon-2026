import React, { useState, useEffect } from 'react';
import LoadingSpinner from '../../components/LoadingSpinner';
import StatusBadge from '../../components/StatusBadge';
import AttendanceCard from '../../components/AttendanceCard';
import { attendanceService } from '../../services/attendanceService';
import { formatDate, formatTime } from '../../utils/formatDate';
import { Clock, Search, Filter } from 'lucide-react';

const AttendanceManagement = () => {
  const [attendance, setAttendance] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchAttendance();
  }, []);

  const fetchAttendance = async () => {
    try {
      setLoading(true);
      const data = await attendanceService.getAllAttendance();
      setAttendance(data || []);
    } catch (err) {
      console.error('Failed to fetch attendance:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading organization attendance log..." />;

  const filtered = attendance.filter((r) => {
    const empName = r.employeeId
      ? `${r.employeeId.firstName || ''} ${r.employeeId.lastName || ''} ${r.employeeId.employeeId || ''}`
      : '';
    return empName.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <Clock className="w-6 h-6 text-indigo-400" /> Organization Attendance Log
          </h2>
          <p className="text-xs text-slate-400">Monitor check-in timestamps, work hours & punctuality across all departments</p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search employee..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="glass-card p-12 text-center text-slate-400 text-xs">
          No attendance records found matching your query.
        </div>
      ) : (
        <div className="hidden sm:block glass-card overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 uppercase font-semibold border-b border-slate-800">
              <tr>
                <th className="px-6 py-4">Employee</th>
                <th className="px-6 py-4">Department</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Check In</th>
                <th className="px-6 py-4">Check Out</th>
                <th className="px-6 py-4">Work Hours</th>
                <th className="px-6 py-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((r) => {
                const emp = r.employeeId || {};
                const name = `${emp.firstName || ''} ${emp.lastName || ''}`.trim() || emp.employeeId || 'Employee';
                return (
                  <tr key={r._id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-6 py-4 font-semibold text-white">
                      <div>{name}</div>
                      <div className="text-[10px] text-indigo-400 font-mono">{emp.employeeId}</div>
                    </td>
                    <td className="px-6 py-4 text-slate-300">{emp.department || 'N/A'}</td>
                    <td className="px-6 py-4 text-slate-300">{formatDate(r.date)}</td>
                    <td className="px-6 py-4 text-emerald-400 font-mono">{formatTime(r.checkIn)}</td>
                    <td className="px-6 py-4 text-indigo-400 font-mono">{formatTime(r.checkOut)}</td>
                    <td className="px-6 py-4 font-bold text-slate-200">{r.workHours || 0} hrs</td>
                    <td className="px-6 py-4">
                      <StatusBadge status={r.status} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Mobile Card Layout */}
      <div className="sm:hidden grid grid-cols-1 gap-4">
        {filtered.map((r) => (
          <AttendanceCard key={r._id} record={r} />
        ))}
      </div>
    </div>
  );
};

export default AttendanceManagement;
