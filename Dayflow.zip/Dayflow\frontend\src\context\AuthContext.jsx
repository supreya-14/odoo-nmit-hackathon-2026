import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../utils/constants';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [employee, setEmployee] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem('dayflow_token') || null);
  const [loading, setLoading] = useState(true);

  // Set default authorization header whenever token changes
  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      localStorage.setItem('dayflow_token', token);
      fetchCurrentUser();
    } else {
      delete axios.defaults.headers.common['Authorization'];
      localStorage.removeItem('dayflow_token');
      setUser(null);
      setEmployee(null);
      setLoading(false);
    }
  }, [token]);

  const fetchCurrentUser = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`${API_BASE_URL}/auth/me`);
      setUser(res.data.user);
      setEmployee(res.data.employee);
    } catch (err) {
      console.error('Failed to fetch user me:', err);
      logout();
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    const res = await axios.post(`${API_BASE_URL}/auth/login`, { email, password });
    const { token: authToken, employee: empProfile, ...userData } = res.data;
    setToken(authToken);
    setUser(userData);
    setEmployee(empProfile);
    return res.data;
  };

  const register = async (formData) => {
    const res = await axios.post(`${API_BASE_URL}/auth/register`, formData);
    const { token: authToken, employee: empProfile, ...userData } = res.data;
    setToken(authToken);
    setUser(userData);
    setEmployee(empProfile);
    return res.data;
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    setEmployee(null);
    localStorage.removeItem('dayflow_token');
  };

  const isAdmin = user && (user.role === 'ADMIN' || user.role === 'HR');

  return (
    <AuthContext.Provider
      value={{
        user,
        employee,
        token,
        loading,
        login,
        register,
        logout,
        isAdmin,
        fetchCurrentUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
