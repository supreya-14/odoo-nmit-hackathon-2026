import React from 'react';
import { Plane, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

const StatusBadge = ({ status, size = 'sm' }) => {
  const normStatus = (status || '').toUpperCase();

  const sizeClasses = size === 'lg' ? 'px-3 py-1.5 text-xs font-semibold' : 'px-2.5 py-1 text-xs font-medium';

  switch (normStatus) {
    case 'PRESENT':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 text-emerald-400 dark:text-emerald-400 light:text-emerald-700 border border-emerald-500/30 ${sizeClasses}`}>
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Present</span>
        </span>
      );

    case 'ON_LEAVE':
    case 'ON LEAVE':
    case 'LEAVE':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-blue-500/15 text-blue-400 dark:text-blue-400 light:text-blue-700 border border-blue-500/30 ${sizeClasses}`}>
          <Plane className="w-3 h-3 text-blue-400 dark:text-blue-400 light:text-blue-600" />
          <span>On Leave</span>
        </span>
      );

    case 'ABSENT':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 text-amber-400 dark:text-amber-400 light:text-amber-700 border border-amber-500/30 ${sizeClasses}`}>
          <span className="h-2 w-2 rounded-full bg-amber-400"></span>
          <span>Absent</span>
        </span>
      );

    case 'LATE':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-orange-500/15 text-orange-400 dark:text-orange-400 light:text-orange-700 border border-orange-500/30 ${sizeClasses}`}>
          <Clock className="w-3 h-3 text-orange-400 dark:text-orange-400 light:text-orange-600" />
          <span>Late</span>
        </span>
      );

    case 'COMPLETED':
    case 'APPROVED':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 text-emerald-400 dark:text-emerald-400 light:text-emerald-700 border border-emerald-500/30 ${sizeClasses}`}>
          <CheckCircle className="w-3 h-3 text-emerald-400 dark:text-emerald-400 light:text-emerald-600" />
          <span>{status}</span>
        </span>
      );

    case 'PENDING':
    case 'IN_PROGRESS':
    case 'TODO':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-indigo-500/15 text-indigo-300 dark:text-indigo-300 light:text-indigo-700 border border-indigo-500/30 ${sizeClasses}`}>
          <span className="h-2 w-2 rounded-full bg-indigo-400"></span>
          <span>{status.replace('_', ' ')}</span>
        </span>
      );

    case 'REJECTED':
    case 'OVERDUE':
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-rose-500/15 text-rose-400 dark:text-rose-400 light:text-rose-700 border border-rose-500/30 ${sizeClasses}`}>
          <AlertTriangle className="w-3 h-3 text-rose-400 dark:text-rose-400 light:text-rose-600" />
          <span>{status}</span>
        </span>
      );

    default:
      return (
        <span className={`inline-flex items-center gap-1.5 rounded-full bg-slate-800 dark:bg-slate-800 light:bg-slate-200 text-slate-300 dark:text-slate-300 light:text-slate-700 border border-slate-700 dark:border-slate-700 light:border-slate-300 ${sizeClasses}`}>
          <span>{status || 'Unknown'}</span>
        </span>
      );
  }
};

export default StatusBadge;
