const Performance = require('../models/Performance');
const Employee = require('../models/Employee');
const { generatePerformanceInsights } = require('../services/aiService');

// @desc    Get current employee's performance record
// @route   GET /api/performance/my
// @access  Private
const getMyPerformance = async (req, res) => {
  try {
    if (!req.employee) {
      return res.status(404).json({ message: 'No associated employee record found' });
    }

    let perf = await Performance.findOne({ employeeId: req.employee._id }).sort({ createdAt: -1 });

    if (!perf) {
      // Default baseline performance if none yet
      perf = await Performance.create({
        employeeId: req.employee._id,
        taskCompletionScore: 85,
        attendanceScore: 90,
        onTimeDeliveryScore: 88,
        productivityScore: 86,
        reviewPeriod: 'Q3 2026',
        strengths: ['Punctual check-ins', 'High quality task submission'],
        weaknesses: ['Documentation clarity'],
        suggestions: ['Participate in team tech talks'],
      });
    }

    res.json(perf);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get performance record by Employee ID (Admin/HR)
// @route   GET /api/performance/:employeeId
// @access  Private
const getPerformanceByEmployeeId = async (req, res) => {
  try {
    let perf = await Performance.findOne({ employeeId: req.params.employeeId }).sort({ createdAt: -1 });

    if (!perf) {
      perf = await Performance.create({
        employeeId: req.params.employeeId,
        taskCompletionScore: 85,
        attendanceScore: 90,
        onTimeDeliveryScore: 85,
        productivityScore: 88,
        reviewPeriod: 'Q3 2026',
      });
    }

    res.json(perf);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create/Update employee performance record (Admin/HR)
// @route   POST /api/performance
// @access  Private/Admin
const createOrUpdatePerformance = async (req, res) => {
  try {
    const {
      employeeId,
      taskCompletionScore,
      attendanceScore,
      onTimeDeliveryScore,
      productivityScore,
      strengths,
      weaknesses,
      suggestions,
      managerFeedback,
      reviewPeriod,
    } = req.body;

    let perf = await Performance.findOne({ employeeId, reviewPeriod: reviewPeriod || 'Q3 2026' });

    if (perf) {
      if (taskCompletionScore !== undefined) perf.taskCompletionScore = taskCompletionScore;
      if (attendanceScore !== undefined) perf.attendanceScore = attendanceScore;
      if (onTimeDeliveryScore !== undefined) perf.onTimeDeliveryScore = onTimeDeliveryScore;
      if (productivityScore !== undefined) perf.productivityScore = productivityScore;
      if (strengths) perf.strengths = strengths;
      if (weaknesses) perf.weaknesses = weaknesses;
      if (suggestions) perf.suggestions = suggestions;
      if (managerFeedback) perf.managerFeedback = managerFeedback;
      perf = await perf.save();
    } else {
      perf = await Performance.create({
        employeeId,
        taskCompletionScore: taskCompletionScore || 80,
        attendanceScore: attendanceScore || 85,
        onTimeDeliveryScore: onTimeDeliveryScore || 80,
        productivityScore: productivityScore || 80,
        strengths: strengths || [],
        weaknesses: weaknesses || [],
        suggestions: suggestions || [],
        managerFeedback: managerFeedback || '',
        reviewPeriod: reviewPeriod || 'Q3 2026',
      });
    }

    res.status(200).json(perf);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Generate Google Gemini AI Performance Insights for employee
// @route   POST /api/performance/:employeeId/ai-insights
// @access  Private/Admin
const generateAiInsights = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.employeeId);
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    let perf = await Performance.findOne({ employeeId: employee._id }).sort({ createdAt: -1 });
    if (!perf) {
      perf = new Performance({
        employeeId: employee._id,
        taskCompletionScore: 85,
        attendanceScore: 90,
        onTimeDeliveryScore: 85,
        productivityScore: 88,
        reviewPeriod: 'Q3 2026',
      });
    }

    const aiOutput = await generatePerformanceInsights(employee, perf);

    perf.aiInsights = aiOutput;
    await perf.save();

    res.json({
      message: 'AI Insights generated successfully',
      aiInsights: perf.aiInsights,
      performance: perf,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getMyPerformance,
  getPerformanceByEmployeeId,
  createOrUpdatePerformance,
  generateAiInsights,
};
