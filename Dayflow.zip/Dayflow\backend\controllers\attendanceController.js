const Attendance = require('../models/Attendance');

// @desc    Check-in attendance for current employee
// @route   POST /api/attendance/check-in
// @access  Private
const checkIn = async (req, res) => {
  try {
    if (!req.employee) {
      return res.status(400).json({ message: 'No employee profile associated with user' });
    }

    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    let existing = await Attendance.findOne({
      employeeId: req.employee._id,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    if (existing && existing.checkIn) {
      return res.status(400).json({ message: 'Already checked in for today', attendance: existing });
    }

    const now = new Date();
    const isLate = now.getHours() >= 10; // Late after 10 AM

    if (!existing) {
      existing = new Attendance({
        employeeId: req.employee._id,
        date: new Date(),
        checkIn: now,
        status: isLate ? 'LATE' : 'PRESENT',
      });
    } else {
      existing.checkIn = now;
      existing.status = isLate ? 'LATE' : 'PRESENT';
    }

    const saved = await existing.save();
    res.status(200).json(saved);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Check-out attendance
// @route   POST /api/attendance/check-out
// @access  Private
const checkOut = async (req, res) => {
  try {
    if (!req.employee) {
      return res.status(400).json({ message: 'No employee profile associated with user' });
    }

    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const existing = await Attendance.findOne({
      employeeId: req.employee._id,
      date: { $gte: startOfDay, $lte: endOfDay },
    });

    if (!existing || !existing.checkIn) {
      return res.status(400).json({ message: 'You have not checked in today yet' });
    }

    if (existing.checkOut) {
      return res.status(400).json({ message: 'Already checked out for today', attendance: existing });
    }

    const now = new Date();
    existing.checkOut = now;

    // Calculate work hours
    const diffMs = now - new Date(existing.checkIn);
    const totalHours = Number((diffMs / (1000 * 60 * 60)).toFixed(2));
    existing.workHours = totalHours;
    existing.extraHours = Math.max(0, Number((totalHours - 8).toFixed(2)));

    const saved = await existing.save();
    res.status(200).json(saved);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get employee's own attendance records
// @route   GET /api/attendance/my
// @access  Private
const getMyAttendance = async (req, res) => {
  try {
    if (!req.employee) {
      return res.json([]);
    }

    const records = await Attendance.find({ employeeId: req.employee._id }).sort({ date: -1 });
    res.json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all employees attendance (Admin/HR)
// @route   GET /api/attendance/all
// @access  Private/Admin
const getAllAttendance = async (req, res) => {
  try {
    const records = await Attendance.find()
      .populate('employeeId', 'firstName lastName employeeId department profileImage')
      .sort({ date: -1 });

    res.json(records);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  checkIn,
  checkOut,
  getMyAttendance,
  getAllAttendance,
};
