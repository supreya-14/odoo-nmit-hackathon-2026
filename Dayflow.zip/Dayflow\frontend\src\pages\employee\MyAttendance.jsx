import React, { useState, useEffect } from 'react';
import AttendanceCard from '../../components/AttendanceCard';
import StatusBadge from '../../components/StatusBadge';
import LoadingSpinner from '../../components/LoadingSpinner';
import { attendanceService } from '../../services/attendanceService';
import { formatDate, formatTime } from '../../utils/formatDate';
import { Clock, Play, Square, Calendar } from 'lucide-react';

const MyAttendance = () => {
  const [attendance, setAttendance] = useState([]);
  const [todayRecord, setTodayRecord] = useState(null);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [toast, setToast] = useState('');

  useEffect(() => {
    fetchAttendance();
  }, []);

  useEffect(() => {
    let interval = null;
    if (todayRecord && todayRecord.checkIn && !todayRecord.checkOut) {
      const startTime = new Date(todayRecord.checkIn).getTime();
      interval = setInterval(() => {
        const now = new Date().getTime();
        setTimerSeconds(Math.floor((now - startTime) / 1000));
      }, 1000);
    } else {
      setTimerSeconds(0);
    }
    return () => clearInterval(interval);
  }, [todayRecord]);

  const fetchAttendance = async () => {
    try {
      setLoading(true);
      const data = await attendanceService.getMyAttendance();
      setAttendance(data || []);

      const todayStr = new Date().toISOString().split('T')[0];
      const rec = (data || []).find((r) => r.date && r.date.startsWith(todayStr));
      setTodayRecord(rec || null);
    } catch (err) {
      console.error('Error fetching attendance:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    try {
      setActionLoading(true);
      const rec = await attendanceService.checkIn();
      setTodayRecord(rec);
      setToast('Check-in recorded!');
      fetchAttendance();
    } catch (err) {
      setToast(err.response?.data?.message || 'Check-in failed');
    } finally {
      setActionLoading(false);
    }
  };

  const handleCheckOut = async () => {
    try {
      setActionLoading(true);
      const rec = await attendanceService.checkOut();
      setTodayRecord(rec);
      setToast('Check-out recorded!');
      fetchAttendance();
    } catch (err) {
      setToast(err.response?.data?.message || 'Check-out failed');
    } finally {
      setActionLoading(false);
    }
  };

  const formatTimer = (totalSecs) => {
    const hrs = String(Math.floor(totalSecs / 3600)).padStart(2, '0');
    const mins = String(Math.floor((totalSecs % 3600) / 60)).padStart(2, '0');
    const secs = String(totalSecs % 60).padStart(2, '0');
    return `${hrs}:${mins}:${secs}`;
  };

  if (loading) return <LoadingSpinner label="Loading attendance logs..." />;

  return (
    <div className="space-y-6 animate-fadeIn">
      {toast && (
        <div className="p-4 rounded-xl bg-indigo-600 text-white font-semibold text-sm shadow-xl flex items-center justify-between">
          <span>{toast}</span>
          <button onClick={() => setToast('')} className="text-xs underline ml-4">
            Dismiss
          </button>
        </div>
      )}

      {/* Header & Live Check-In Terminal - Rich Indigo Gradient */}
      <div className="glass-card p-6 md:p-8 bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 dark:from-indigo-950 dark:via-slate-900 dark:to-purple-950 border border-indigo-500/30 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-5 h-5 text-indigo-300 dark:text-indigo-400" />
              <span className="text-xs uppercase tracking-widest font-bold text-indigo-200 dark:text-indigo-400">
                Attendance Terminal
              </span>
            </div>
            <h2 className="text-2xl md:text-3xl font-extrabold text-white">Daily Attendance & Work Hours</h2>
            <p className="text-xs text-indigo-100 dark:text-slate-400 mt-1">
              Track check-ins, check-outs, and total daily duration
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 dark:bg-slate-950/80 backdrop-blur-md border border-white/20 dark:border-slate-800/80 flex items-center gap-4">
            {todayRecord?.checkIn && !todayRecord?.checkOut ? (
              <div className="flex items-center gap-4">
                <div className="text-left">
                  <span className="text-[10px] uppercase font-bold text-indigo-100 dark:text-slate-400 block">
                    Shift Timer
                  </span>
                  <span className="text-2xl font-mono font-bold text-emerald-300 dark:text-emerald-400">
                    {formatTimer(timerSeconds)}
                  </span>
                </div>
                <button
                  onClick={handleCheckOut}
                  disabled={actionLoading}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-rose-600/20"
                >
                  <Square className="w-4 h-4 fill-current" />
                  <span>Check Out</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <div className="text-left">
                  <span className="text-[10px] uppercase font-bold text-indigo-100 dark:text-slate-400 block">
                    Today's Status
                  </span>
                  <StatusBadge status={todayRecord ? todayRecord.status : 'ABSENT'} size="lg" />
                </div>
                {!todayRecord?.checkOut && (
                  <button
                    onClick={handleCheckIn}
                    disabled={actionLoading}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-emerald-600/20"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Check In Now</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Attendance History Table / Cards */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Calendar className="w-5 h-5 text-indigo-500" /> Attendance History
        </h3>

        {attendance.length === 0 ? (
          <div className="glass-card p-12 text-center text-slate-400 text-xs">
            No attendance records found yet. Check in above to create your first entry!
          </div>
        ) : (
          <div className="hidden sm:block glass-card overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-900/90 text-slate-700 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4">Check In</th>
                  <th className="px-6 py-4">Check Out</th>
                  <th className="px-6 py-4">Work Hours</th>
                  <th className="px-6 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                {attendance.map((r) => (
                  <tr
                    key={r._id}
                    className="bg-white dark:bg-slate-900/50 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="px-6 py-4 font-semibold text-slate-900 dark:text-slate-100">
                      {formatDate(r.date)}
                    </td>
                    <td className="px-6 py-4 text-emerald-600 dark:text-emerald-400 font-mono font-semibold">
                      {formatTime(r.checkIn)}
                    </td>
                    <td className="px-6 py-4 text-indigo-600 dark:text-indigo-400 font-mono font-semibold">
                      {formatTime(r.checkOut)}
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-800 dark:text-slate-200">
                      {r.workHours || 0} hrs
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={r.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Mobile View: Cards */}
        <div className="sm:hidden grid grid-cols-1 gap-4">
          {attendance.map((r) => (
            <AttendanceCard key={r._id} record={r} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default MyAttendance;
