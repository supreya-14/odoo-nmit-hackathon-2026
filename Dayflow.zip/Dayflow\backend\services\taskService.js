const Task = require('../models/Task');

const calculateTaskStats = async (employeeId = null) => {
  const filter = employeeId ? { assignedTo: employeeId } : {};
  const total = await Task.countDocuments(filter);
  const completed = await Task.countDocuments({ ...filter, status: 'COMPLETED' });
  const pending = await Task.countDocuments({ ...filter, status: { $in: ['TODO', 'IN_PROGRESS', 'REVIEW'] } });
  const overdue = await Task.countDocuments({ ...filter, status: 'OVERDUE' });

  const completionRate = total > 0 ? Math.round((completed / total) * 100) : 100;

  return { total, completed, pending, overdue, completionRate };
};

module.exports = { calculateTaskStats };
