/**
 * Helper function to generate standardized Dayflow Employee IDs
 * Format: [COMPANY_2LETTER]-[FN_2LETTER][LN_2LETTER]-[YEAR]-[4DIGIT_SERIAL]
 * Example: OT-JODO-2023-0001
 */
const generateEmployeeId = (companyName = 'OneTech', firstName = 'John', lastName = 'Doe', joiningYear = new Date().getFullYear(), count = 1) => {
  const companyPrefix = (companyName.replace(/[^a-zA-Z]/g, '').substring(0, 2) || 'OT').toUpperCase();
  const fnPrefix = (firstName.replace(/[^a-zA-Z]/g, '').substring(0, 2) || 'JO').toUpperCase();
  const lnPrefix = (lastName.replace(/[^a-zA-Z]/g, '').substring(0, 2) || 'DO').toUpperCase();
  const serial = String(count).padStart(4, '0');

  return `${companyPrefix}-${fnPrefix}${lnPrefix}-${joiningYear}-${serial}`;
};

module.exports = generateEmployeeId;
