const jwt = require('jsonwebtoken');

const generateToken = (id, role, employeeId) => {
  return jwt.sign(
    { id, role, employeeId },
    process.env.JWT_SECRET || 'dayflow_default_secret_key_2026',
    { expiresIn: '30d' }
  );
};

module.exports = generateToken;
