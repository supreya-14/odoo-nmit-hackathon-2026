import React from 'react';
import StatusBadge from './StatusBadge';
import { formatDate } from '../utils/formatDate';
import { Calendar, FileText, Check, X } from 'lucide-react';

const LeaveCard = ({ leave, onApprove, onReject, isAdmin = false }) => {
  const { _id, leaveType, startDate, endDate, numberOfDays, reason, status, employeeId } = leave;

  const empName = employeeId
    ? `${employeeId.firstName || ''} ${employeeId.lastName || ''}`.trim() || employeeId.employeeId
    : 'Employee';

  return (
    <div className="glass-card p-5 flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="px-2.5 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-semibold">
            {leaveType}
          </span>
          <StatusBadge status={status} />
        </div>

        {isAdmin && (
          <p className="text-xs font-bold text-white mb-2">
            Requested by: <span className="text-indigo-400 font-normal">{empName}</span>
          </p>
        )}

        <div className="flex items-center gap-2 text-xs text-slate-300 mb-3 bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60">
          <Calendar className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            {formatDate(startDate)} → {formatDate(endDate)}
          </span>
          <span className="ml-auto font-bold text-indigo-400">({numberOfDays} {numberOfDays === 1 ? 'day' : 'days'})</span>
        </div>

        <div className="flex items-start gap-2 text-xs text-slate-400 mb-4">
          <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
          <p className="line-clamp-2 italic">"{reason}"</p>
        </div>
      </div>

      {isAdmin && status === 'PENDING' && (
        <div className="pt-3 border-t border-slate-800/80 grid grid-cols-2 gap-2">
          <button
            onClick={() => onApprove(_id)}
            className="flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition-colors"
          >
            <Check className="w-3.5 h-3.5" /> Approve
          </button>
          <button
            onClick={() => onReject(_id)}
            className="flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 text-xs font-semibold transition-colors"
          >
            <X className="w-3.5 h-3.5" /> Reject
          </button>
        </div>
      )}
    </div>
  );
};

export default LeaveCard;
