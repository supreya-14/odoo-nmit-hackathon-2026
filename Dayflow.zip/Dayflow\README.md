# Dayflow – Smart Employee Performance & Task Management System

Dayflow is a production-grade, AI-powered Human Resource Management and Employee Productivity Platform. Built with a modern dark-first SaaS aesthetic (Linear / Notion / Vercel style), Dayflow empowers organizations to streamline employee lifecycle management, attendance tracking, task delegation, leave approvals, salary calculations, and AI-driven performance insights.

---

## Problem Statement
Traditional HR and employee task management systems are often fragmented, visually outdated, and lack automated performance evaluation. Organizations struggle with manual salary calculations, delayed leave processing, opaque attendance logs, and subjective employee performance reviews.

## Solution
Dayflow unifies core HR operations, real-time shift timers, interactive task pipelines, role-based access security, automated compensation breakdowns, and Google Gemini AI analytics into one seamless, responsive web platform.

---

## Key Features

- **Auto-Generated Employee IDs**: Standardized format `[COMPANY]-[FN][LN]-[YEAR]-[SERIAL]` (e.g. `OT-JODO-2026-0001`).
- **Live Attendance Terminal**: Real-time shift timer with check-in, check-out, and scannable status indicators:
  - 🟢 **Green Dot** = Present
  - ✈️ **Plane Icon** = On Leave
  - 🟠 **Amber Dot** = Absent / Late
- **Interactive Task Pipeline**: Assign tasks, set priorities (`URGENT`, `HIGH`, `MEDIUM`, `LOW`), update progress percentage, and log comments.
- **Leave & Time Off Management**: Multi-type leave requests (PTO, Sick Leave, Unpaid) with real-time balance tracking and Admin approval workflows.
- **Salary & Compensation Module (Admin Only)**: Automated component calculations (Basic 50%, HRA 50% Basic, PF 12%, Professional Tax). Strictly hidden from non-admin accounts.
- **Weighted Performance Scoring**: Multi-factor evaluation formula:
  $$\text{Overall Score} = 0.40 \times \text{Task} + 0.20 \times \text{Attendance} + 0.20 \times \text{Delivery} + 0.20 \times \text{Productivity}$$
- **Google Gemini AI Performance Insights**: Generates executive summaries, identified strengths, growth points, and recommended Q4 goals.
- **Dark-First SaaS Aesthetic**: Glassmorphism cards, ambient flow glow backdrop, Recharts charts, and smooth micro-interactions.

---

## User Roles & Access Control

| Role | Access Permissions |
| text | ------------------ |
| **ADMIN / HR** | Full management console access, create employees, view all salary data, assign tasks, approve/reject leaves, generate Gemini AI insights, view organization-wide Recharts analytics. |
| **EMPLOYEE** | Personal workspace only, view assigned tasks, update progress & submit comments, mark attendance check-in/check-out with live timer, apply for leave, view personal performance score. Restricted from viewing salary data or other employees' private records. |

---

## Tech Stack

- **Frontend**: React 18, Vite, Tailwind CSS, React Router v6, Axios, Lucide React, Recharts, Context API (Auth + Theme).
- **Backend**: Node.js, Express.js, MongoDB, Mongoose ODM, JWT Authentication, bcryptjs, REST APIs.
- **AI**: Google Gemini 1.5 Flash API / `@google/genai`.
- **Database**: MongoDB Atlas / Local MongoDB.

---

## Project Folder Structure

```
Dayflow/
├── frontend/
│   ├── public/
│   │   └── favicon.ico
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx
│   │   │   ├── Sidebar.jsx
│   │   │   ├── ProfileDropdown.jsx
│   │   │   ├── EmployeeCard.jsx
│   │   │   ├── TaskCard.jsx
│   │   │   ├── AttendanceCard.jsx
│   │   │   ├── LeaveCard.jsx
│   │   │   ├── PerformanceCard.jsx
│   │   │   ├── StatusBadge.jsx
│   │   │   ├── Modal.jsx
│   │   │   ├── LoadingSpinner.jsx
│   │   │   └── ProtectedRoute.jsx
│   │   ├── pages/
│   │   │   ├── auth/ (Login.jsx, Register.jsx)
│   │   │   ├── employee/ (EmployeeDashboard, MyProfile, MyTasks, MyAttendance, MyLeave, MyPerformance)
│   │   │   ├── admin/ (AdminDashboard, Employees, EmployeeDetails, TaskManagement, AttendanceManagement, LeaveManagement, PerformanceDashboard)
│   │   │   └── NotFound.jsx
│   │   ├── services/ (api.js, authService, employeeService, taskService, attendanceService, leaveService, performanceService)
│   │   ├── context/ (AuthContext.jsx, ThemeContext.jsx)
│   │   ├── utils/ (formatDate.js, constants.js)
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
├── backend/
│   ├── config/ (db.js)
│   ├── database/ (database.js, seed.js)
│   ├── models/ (User.js, Employee.js, Task.js, Attendance.js, Leave.js, Performance.js)
│   ├── controllers/ (authController, employeeController, taskController, attendanceController, leaveController, performanceController)
│   ├── routes/ (authRoutes, employeeRoutes, taskRoutes, attendanceRoutes, leaveRoutes, performanceRoutes)
│   ├── services/ (taskService, attendanceService, performanceService, aiService)
│   ├── middleware/ (authMiddleware, adminMiddleware, errorMiddleware)
│   ├── utils/ (generateToken.js, generateEmployeeId.js)
│   ├── server.js
│   └── package.json
├── database/
│   ├── README.md
│   ├── collections.md
│   └── sample-data/ (*.json)
├── README.md
├── .gitignore
└── .env.example
```

---

## API Endpoints Summary

### Authentication (`/api/auth`)
- `POST /api/auth/register` - Register user & create employee profile
- `POST /api/auth/login` - Authenticate user & issue JWT
- `GET  /api/auth/me` - Fetch authenticated user profile

### Employees (`/api/employees`)
- `GET    /api/employees` - List all employees (Salary sanitized for non-admin)
- `GET    /api/employees/:id` - Get employee details
- `POST   /api/employees` - Admin create employee with auto salary calculation
- `PUT    /api/employees/:id` - Update employee profile
- `DELETE /api/employees/:id` - Delete employee record

### Tasks (`/api/tasks`)
- `GET    /api/tasks` - List tasks (Filtered for regular employees)
- `POST   /api/tasks` - Admin create task
- `PUT    /api/tasks/:id` - Update status, progress slider, add comments

### Attendance (`/api/attendance`)
- `POST /api/attendance/check-in` - Log check-in timestamp
- `POST /api/attendance/check-out` - Log check-out & compute duration
- `GET  /api/attendance/my` - Employee attendance log
- `GET  /api/attendance/all` - Admin organization-wide attendance log

### Leaves (`/api/leaves`)
- `POST /api/leaves` - Apply for time off
- `GET  /api/leaves/my` - Employee leave history & balance
- `GET  /api/leaves/all` - Admin all leave applications
- `PUT  /api/leaves/:id/approve` - Approve leave request
- `PUT  /api/leaves/:id/reject` - Reject leave request with reason

### Performance & AI (`/api/performance`)
- `GET  /api/performance/my` - Employee performance scorecard
- `GET  /api/performance/:employeeId` - Admin view employee performance
- `POST /api/performance` - Admin update weighted scores
- `POST /api/performance/:employeeId/ai-insights` - Trigger Google Gemini AI analysis

---

## Installation & Running Commands

### 1. Prerequisites
- Node.js (v18 or higher)
- MongoDB instance (local or MongoDB Atlas connection string)

### 2. Environment Setup
Fill out `backend/.env`:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/dayflow
JWT_SECRET=dayflow_super_secret_jwt_key_2026_production
GEMINI_API_KEY=your_google_gemini_api_key
CLIENT_URL=http://localhost:5173
```

Fill out `frontend/.env`:
```env
VITE_API_URL=http://localhost:5000/api
```

### 3. Backend Setup & Database Seeding
```bash
cd backend
npm install
npm run seed
npm run dev
```

### 4. Frontend Setup & Run
```bash
cd frontend
npm install
npm run dev
```

---

## Demo Login Credentials

- **Admin / HR Account**:
  - Email: `admin@dayflow.com`
  - Password: `Admin@123`
  - Role: `ADMIN`

- **Employee Account (John Doe)**:
  - Email: `john.doe@dayflow.com`
  - Password: `Password@123`
  - Role: `EMPLOYEE`

---

## Deployment Guidelines

### Frontend (Vercel)
1. Push `frontend/` to GitHub.
2. Import project into Vercel dashboard.
3. Set build command `npm run build` and output directory `dist`.
4. Add environment variable `VITE_API_URL=https://your-backend.onrender.com/api`.

### Backend (Render)
1. Push `backend/` to GitHub.
2. Create a new Web Service on Render.
3. Set build command `npm install` and start command `node server.js`.
4. Add environment variables (`MONGODB_URI`, `JWT_SECRET`, `GEMINI_API_KEY`).

---

## License
MIT License. Crafted for high-performance HR SaaS applications.
