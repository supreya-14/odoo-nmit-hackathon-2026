const Task = require('../models/Task');
const Employee = require('../models/Employee');

// @desc    Get all tasks (Admin gets all, Employee gets assigned)
// @route   GET /api/tasks
// @access  Private
const getTasks = async (req, res) => {
  try {
    let query = {};
    if (req.user.role === 'EMPLOYEE') {
      if (!req.employee) {
        return res.json([]);
      }
      query.assignedTo = req.employee._id;
    }

    const tasks = await Task.find(query)
      .populate('assignedTo', 'firstName lastName employeeId department profileImage')
      .populate('createdBy', 'email role')
      .sort({ createdAt: -1 });

    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single task
// @route   GET /api/tasks/:id
// @access  Private
const getTaskById = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id)
      .populate('assignedTo', 'firstName lastName employeeId department profileImage')
      .populate('createdBy', 'email role');

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    res.json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create a task (Admin/HR)
// @route   POST /api/tasks
// @access  Private/Admin
const createTask = async (req, res) => {
  try {
    const { title, description, assignedTo, priority, dueDate } = req.body;

    const task = await Task.create({
      title,
      description,
      assignedTo,
      createdBy: req.user._id,
      priority: priority || 'MEDIUM',
      status: 'TODO',
      dueDate: dueDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      progress: 0,
    });

    const populatedTask = await Task.findById(task._id).populate('assignedTo', 'firstName lastName employeeId');
    res.status(201).json(populatedTask);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update task status / progress / details
// @route   PUT /api/tasks/:id
// @access  Private
const updateTask = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    const { title, description, priority, status, progress, commentText } = req.body;

    if (status !== undefined) task.status = status;
    if (progress !== undefined) {
      task.progress = Number(progress);
      if (task.progress === 100) {
        task.status = 'COMPLETED';
        task.completionDate = new Date();
      }
    }

    if (req.user.role === 'ADMIN' || req.user.role === 'HR') {
      if (title) task.title = title;
      if (description) task.description = description;
      if (priority) task.priority = priority;
    }

    if (commentText) {
      const authorName = req.employee ? `${req.employee.firstName} ${req.employee.lastName}` : req.user.email;
      task.comments.push({
        authorId: req.user._id,
        authorName,
        text: commentText,
        createdAt: new Date(),
      });
    }

    const updatedTask = await task.save();
    const populated = await Task.findById(updatedTask._id).populate('assignedTo', 'firstName lastName employeeId');
    res.json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete task (Admin)
// @route   DELETE /api/tasks/:id
// @access  Private/Admin
const deleteTask = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getTasks,
  getTaskById,
  createTask,
  updateTask,
  deleteTask,
};
