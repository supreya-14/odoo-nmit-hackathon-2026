const mongoose = require('mongoose');

const performanceSchema = new mongoose.Schema(
  {
    employeeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
      required: true,
    },
    taskCompletionScore: {
      type: Number,
      default: 80,
      min: 0,
      max: 100,
    },
    attendanceScore: {
      type: Number,
      default: 90,
      min: 0,
      max: 100,
    },
    onTimeDeliveryScore: {
      type: Number,
      default: 85,
      min: 0,
      max: 100,
    },
    productivityScore: {
      type: Number,
      default: 85,
      min: 0,
      max: 100,
    },
    overallScore: {
      type: Number,
      default: 85,
    },
    strengths: [{ type: String }],
    weaknesses: [{ type: String }],
    suggestions: [{ type: String }],
    managerFeedback: { type: String, default: '' },
    aiInsights: {
      summary: { type: String, default: '' },
      strengths: [{ type: String }],
      areasForImprovement: [{ type: String }],
      recommendedGoals: [{ type: String }],
    },
    reviewPeriod: { type: String, default: 'Q3 2026' },
  },
  {
    timestamps: true,
  }
);

// Auto-calculate weighted score before saving
performanceSchema.pre('save', function (next) {
  this.overallScore = Number(
    (
      this.taskCompletionScore * 0.4 +
      this.attendanceScore * 0.2 +
      this.onTimeDeliveryScore * 0.2 +
      this.productivityScore * 0.2
    ).toFixed(1)
  );
  next();
});

const Performance = mongoose.model('Performance', performanceSchema);
module.exports = Performance;
