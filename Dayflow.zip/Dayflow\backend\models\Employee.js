const mongoose = require('mongoose');

const salarySchema = new mongoose.Schema({
  wageType: { type: String, enum: ['MONTHLY', 'HOURLY'], default: 'MONTHLY' },
  monthlyWage: { type: Number, default: 0 },
  yearlyWage: { type: Number, default: 0 },
  basicSalary: { type: Number, default: 0 },
  hra: { type: Number, default: 0 },
  standardAllowance: { type: Number, default: 0 },
  performanceBonus: { type: Number, default: 0 },
  lta: { type: Number, default: 0 },
  fixedAllowance: { type: Number, default: 0 },
  providentFund: { type: Number, default: 0 },
  professionalTax: { type: Number, default: 200 },
  workingDays: { type: Number, default: 22 },
  breakTime: { type: Number, default: 60 },
});

const employeeSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    employeeId: {
      type: String,
      required: true,
      unique: true,
    },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, default: '' },
    profileImage: { type: String, default: '' },
    company: { type: String, default: 'OneTech Solutions' },
    department: { type: String, required: true },
    jobPosition: { type: String, required: true },
    manager: { type: String, default: 'HR Manager' },
    location: { type: String, default: 'Headquarters' },
    dateOfBirth: { type: Date },
    joiningDate: { type: Date, default: Date.now },
    address: { type: String, default: '' },
    nationality: { type: String, default: 'American' },
    gender: { type: String, enum: ['Male', 'Female', 'Other', 'Prefer Not to Say'], default: 'Prefer Not to Say' },
    maritalStatus: { type: String, enum: ['Single', 'Married', 'Divorced', 'Widowed'], default: 'Single' },
    skills: [{ type: String }],
    certifications: [{ type: String }],
    about: { type: String, default: '' },
    interests: [{ type: String }],
    resume: { type: String, default: '' },
    salary: { type: salarySchema, default: () => ({}) },
  },
  {
    timestamps: true,
  }
);

const Employee = mongoose.model('Employee', employeeSchema);
module.exports = Employee;
