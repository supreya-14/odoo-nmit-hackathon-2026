import React, { useState, useEffect } from 'react';
import LeaveCard from '../../components/LeaveCard';
import Modal from '../../components/Modal';
import LoadingSpinner from '../../components/LoadingSpinner';
import { leaveService } from '../../services/leaveService';
import { CalendarDays, Plus, Info } from 'lucide-react';

const MyLeave = () => {
  const [leaves, setLeaves] = useState([]);
  const [leaveBalance, setLeaveBalance] = useState({ ptoRemaining: 15, sickRemaining: 10, unpaidTaken: 0 });
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    leaveType: 'Paid Time Off',
    startDate: '',
    endDate: '',
    reason: '',
  });

  useEffect(() => {
    fetchLeaves();
  }, []);

  const fetchLeaves = async () => {
    try {
      setLoading(true);
      const res = await leaveService.getMyLeaves();
      setLeaves(res.leaves || []);
      if (res.leaveBalance) setLeaveBalance(res.leaveBalance);
    } catch (err) {
      console.error('Error fetching leaves:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await leaveService.apply(formData);
      setIsModalOpen(false);
      setFormData({ leaveType: 'Paid Time Off', startDate: '', endDate: '', reason: '' });
      fetchLeaves();
    } catch (err) {
      console.error('Apply leave error:', err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading time off records..." />;

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-indigo-400" /> Time Off & Leave Portal
          </h2>
          <p className="text-xs text-slate-400">Request leave, track approval status, and manage PTO allowance</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-xs transition-all shadow-lg shadow-indigo-600/25"
        >
          <Plus className="w-4 h-4" />
          <span>New Leave Request</span>
        </button>
      </div>

      {/* Leave Balances Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="glass-card p-5 border-indigo-500/30 bg-indigo-950/20">
          <span className="text-xs font-semibold text-indigo-400 block mb-1">Paid Time Off (PTO)</span>
          <div className="text-2xl font-extrabold text-white">{leaveBalance.ptoRemaining} Days Left</div>
          <span className="text-[11px] text-slate-400 block mt-1">15 days standard annual allotment</span>
        </div>

        <div className="glass-card p-5 border-emerald-500/30 bg-emerald-950/20">
          <span className="text-xs font-semibold text-emerald-400 block mb-1">Sick Leave</span>
          <div className="text-2xl font-extrabold text-white">{leaveBalance.sickRemaining} Days Left</div>
          <span className="text-[11px] text-slate-400 block mt-1">10 days annual allowance</span>
        </div>

        <div className="glass-card p-5 border-purple-500/30 bg-purple-950/20">
          <span className="text-xs font-semibold text-purple-300 block mb-1">Unpaid Leave Taken</span>
          <div className="text-2xl font-extrabold text-white">{leaveBalance.unpaidTaken} Days</div>
          <span className="text-[11px] text-slate-400 block mt-1">Total unpaid days taken</span>
        </div>
      </div>

      {/* Requests History */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-white">My Leave Requests</h3>
        {leaves.length === 0 ? (
          <div className="glass-card p-12 text-center text-slate-400 text-xs">
            No leave requests submitted yet. Click "New Leave Request" to submit one.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {leaves.map((l) => (
              <LeaveCard key={l._id} leave={l} />
            ))}
          </div>
        )}
      </div>

      {/* Apply Leave Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Apply for Time Off / Leave">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Leave Type</label>
            <select
              value={formData.leaveType}
              onChange={(e) => setFormData({ ...formData, leaveType: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
            >
              <option value="Paid Time Off">Paid Time Off (PTO)</option>
              <option value="Sick Leave">Sick Leave</option>
              <option value="Unpaid Leave">Unpaid Leave</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Start Date</label>
              <input
                type="date"
                required
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">End Date</label>
              <input
                type="date"
                required
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Reason for Request</label>
            <textarea
              rows={3}
              required
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              placeholder="Explain the reason for time off..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
            ></textarea>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors"
          >
            {submitting ? 'Submitting...' : 'Submit Request for Approval'}
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default MyLeave;
