import React, { useState, useEffect } from 'react';
import TaskCard from '../../components/TaskCard';
import Modal from '../../components/Modal';
import LoadingSpinner from '../../components/LoadingSpinner';
import { taskService } from '../../services/taskService';
import { CheckSquare, Filter, Plus, MessageSquare, Send } from 'lucide-react';

const MyTasks = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState(null);
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [commentInput, setCommentInput] = useState('');
  const [progressInput, setProgressInput] = useState(0);
  const [statusInput, setStatusInput] = useState('TODO');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const data = await taskService.getAll();
      setTasks(data || []);
    } catch (err) {
      console.error('Failed to fetch my tasks:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenTask = (task) => {
    setSelectedTask(task);
    setProgressInput(task.progress || 0);
    setStatusInput(task.status || 'TODO');
    setCommentInput('');
  };

  const handleUpdateTask = async (e) => {
    e.preventDefault();
    if (!selectedTask) return;
    setUpdating(true);

    try {
      const updated = await taskService.update(selectedTask._id, {
        progress: progressInput,
        status: statusInput,
        commentText: commentInput,
      });

      setTasks((prev) => prev.map((t) => (t._id === updated._id ? updated : t)));
      setSelectedTask(updated);
      setCommentInput('');
    } catch (err) {
      console.error('Task update failed:', err);
    } finally {
      setUpdating(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading assigned tasks..." />;

  const filteredTasks = tasks.filter((t) => {
    if (filterStatus === 'ALL') return true;
    return t.status === filterStatus;
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-indigo-400" /> My Tasks
          </h2>
          <p className="text-xs text-slate-400">View and update your sprint tasks and deliverable progress</p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
          <Filter className="w-4 h-4 text-slate-500 ml-2" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-transparent text-xs text-slate-200 focus:outline-none pr-2 cursor-pointer font-medium"
          >
            <option value="ALL" className="bg-slate-900">All Statuses</option>
            <option value="TODO" className="bg-slate-900">To Do</option>
            <option value="IN_PROGRESS" className="bg-slate-900">In Progress</option>
            <option value="REVIEW" className="bg-slate-900">In Review</option>
            <option value="COMPLETED" className="bg-slate-900">Completed</option>
          </select>
        </div>
      </div>

      {/* Task Grid */}
      {filteredTasks.length === 0 ? (
        <div className="glass-card p-12 text-center text-slate-400 text-xs">
          No tasks found matching current filter.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTasks.map((t) => (
            <TaskCard key={t._id} task={t} onClick={handleOpenTask} />
          ))}
        </div>
      )}

      {/* Task Update Modal */}
      {selectedTask && (
        <Modal
          isOpen={!!selectedTask}
          onClose={() => setSelectedTask(null)}
          title={`Task: ${selectedTask.title}`}
        >
          <div className="space-y-6">
            <p className="text-xs text-slate-300 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              {selectedTask.description}
            </p>

            <form onSubmit={handleUpdateTask} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Status</label>
                  <select
                    value={statusInput}
                    onChange={(e) => setStatusInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="TODO">To Do</option>
                    <option value="IN_PROGRESS">In Progress</option>
                    <option value="REVIEW">In Review</option>
                    <option value="COMPLETED">Completed</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Progress Slider ({progressInput}%)
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={progressInput}
                    onChange={(e) => setProgressInput(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 mt-2"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Add Update / Comment</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    placeholder="Type progress update or notes..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                  />
                  <button
                    type="submit"
                    disabled={updating}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shrink-0 transition-colors"
                  >
                    {updating ? 'Saving...' : 'Submit Update'}
                  </button>
                </div>
              </div>
            </form>

            {/* Comment Thread */}
            {selectedTask.comments?.length > 0 && (
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-indigo-400" /> Activity Log
                </h4>
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {selectedTask.comments.map((c, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
                      <div className="flex justify-between font-semibold text-indigo-300 mb-0.5">
                        <span>{c.authorName}</span>
                        <span className="text-[10px] text-slate-500">{new Date(c.createdAt).toLocaleDateString()}</span>
                      </div>
                      <p className="text-slate-300">{c.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};

export default MyTasks;
