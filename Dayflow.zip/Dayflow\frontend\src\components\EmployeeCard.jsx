import React from 'react';
import StatusBadge from './StatusBadge';
import { Mail, Phone, MapPin, Award } from 'lucide-react';

const EmployeeCard = ({ employee, onClick }) => {
  const {
    firstName,
    lastName,
    employeeId,
    department,
    jobPosition,
    email,
    phone,
    location,
    attendanceStatus = 'PRESENT',
    performanceScore = 90,
  } = employee;

  const fullName = `${firstName} ${lastName}`;

  return (
    <div
      onClick={() => onClick && onClick(employee)}
      className="glass-card-hover p-5 cursor-pointer flex flex-col justify-between"
    >
      <div>
        {/* Top Header & Status */}
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center font-bold text-white text-lg shadow-md">
              {firstName?.charAt(0)}
              {lastName?.charAt(0)}
            </div>
            <div>
              <h4 className="font-semibold text-white text-base leading-tight group-hover:text-indigo-400 transition-colors">
                {fullName}
              </h4>
              <p className="text-xs font-mono text-indigo-400 mt-0.5">{employeeId}</p>
            </div>
          </div>
          <StatusBadge status={attendanceStatus} />
        </div>

        {/* Info Grid */}
        <div className="space-y-1.5 text-xs text-slate-300 mb-4">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-md bg-slate-800 text-indigo-300 font-medium">{department}</span>
            <span className="text-slate-400">•</span>
            <span className="text-slate-300 font-medium truncate">{jobPosition}</span>
          </div>

          <div className="flex items-center gap-2 text-slate-400 pt-1">
            <Mail className="w-3.5 h-3.5 text-slate-500" />
            <span className="truncate">{email}</span>
          </div>

          {location && (
            <div className="flex items-center gap-2 text-slate-400">
              <MapPin className="w-3.5 h-3.5 text-slate-500" />
              <span className="truncate">{location}</span>
            </div>
          )}
        </div>
      </div>

      {/* Footer Metrics */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs">
          <Award className="w-4 h-4 text-amber-400" />
          <span className="text-slate-400">Score:</span>
          <span className="font-bold text-emerald-400">{performanceScore}%</span>
        </div>
        <span className="text-[11px] text-indigo-400 hover:underline font-medium">View Details →</span>
      </div>
    </div>
  );
};

export default EmployeeCard;
