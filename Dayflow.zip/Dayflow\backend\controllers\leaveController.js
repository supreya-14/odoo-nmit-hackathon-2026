const Leave = require('../models/Leave');

// @desc    Apply for leave (Employee)
// @route   POST /api/leaves
// @access  Private
const applyLeave = async (req, res) => {
  try {
    if (!req.employee) {
      return res.status(400).json({ message: 'No employee profile associated with user' });
    }

    const { leaveType, startDate, endDate, reason, attachment } = req.body;

    const start = new Date(startDate);
    const end = new Date(endDate);

    if (end < start) {
      return res.status(400).json({ message: 'End date cannot be prior to start date' });
    }

    const diffTime = Math.abs(end - start);
    const numberOfDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

    const leave = await Leave.create({
      employeeId: req.employee._id,
      leaveType: leaveType || 'Paid Time Off',
      startDate: start,
      endDate: end,
      numberOfDays,
      reason,
      attachment: attachment || '',
      status: 'PENDING',
    });

    const populated = await Leave.findById(leave._id).populate('employeeId', 'firstName lastName employeeId department');
    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get employee's own leave history
// @route   GET /api/leaves/my
// @access  Private
const getMyLeaves = async (req, res) => {
  try {
    if (!req.employee) {
      return res.json([]);
    }

    const leaves = await Leave.find({ employeeId: req.employee._id }).sort({ createdAt: -1 });

    const ptoCount = leaves.filter(l => l.leaveType === 'Paid Time Off' && l.status === 'APPROVED').reduce((acc, curr) => acc + curr.numberOfDays, 0);
    const sickCount = leaves.filter(l => l.leaveType === 'Sick Leave' && l.status === 'APPROVED').reduce((acc, curr) => acc + curr.numberOfDays, 0);

    const leaveBalance = {
      ptoRemaining: Math.max(0, 15 - ptoCount),
      sickRemaining: Math.max(0, 10 - sickCount),
      unpaidTaken: leaves.filter(l => l.leaveType === 'Unpaid Leave' && l.status === 'APPROVED').reduce((acc, curr) => acc + curr.numberOfDays, 0),
    };

    res.json({ leaves, leaveBalance });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all leave requests (Admin/HR)
// @route   GET /api/leaves/all
// @access  Private/Admin
const getAllLeaves = async (req, res) => {
  try {
    const leaves = await Leave.find()
      .populate('employeeId', 'firstName lastName employeeId department profileImage')
      .sort({ createdAt: -1 });

    res.json(leaves);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Approve leave request (Admin/HR)
// @route   PUT /api/leaves/:id/approve
// @access  Private/Admin
const approveLeave = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) {
      return res.status(404).json({ message: 'Leave request not found' });
    }

    leave.status = 'APPROVED';
    leave.approvedBy = req.user._id;
    leave.approvedAt = new Date();

    const updated = await leave.save();
    const populated = await Leave.findById(updated._id).populate('employeeId', 'firstName lastName employeeId department');
    res.json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Reject leave request (Admin/HR)
// @route   PUT /api/leaves/:id/reject
// @access  Private/Admin
const rejectLeave = async (req, res) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) {
      return res.status(404).json({ message: 'Leave request not found' });
    }

    const { rejectionReason } = req.body;
    leave.status = 'REJECTED';
    leave.approvedBy = req.user._id;
    leave.approvedAt = new Date();
    leave.rejectionReason = rejectionReason || 'Request does not meet operational guidelines';

    const updated = await leave.save();
    const populated = await Leave.findById(updated._id).populate('employeeId', 'firstName lastName employeeId department');
    res.json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  applyLeave,
  getMyLeaves,
  getAllLeaves,
  approveLeave,
  rejectLeave,
};
