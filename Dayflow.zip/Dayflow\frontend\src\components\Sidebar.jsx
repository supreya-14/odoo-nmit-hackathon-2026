import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Users,
  CheckSquare,
  Clock,
  CalendarDays,
  TrendingUp,
  UserCheck,
  Zap,
  X,
} from 'lucide-react';

const Sidebar = ({ isOpen, onClose }) => {
  const { isAdmin } = useAuth();

  const adminLinks = [
    { to: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/admin/employees', label: 'Employees', icon: Users },
    { to: '/admin/tasks', label: 'Task Management', icon: CheckSquare },
    { to: '/admin/attendance', label: 'Attendance Log', icon: Clock },
    { to: '/admin/leaves', label: 'Leave Requests', icon: CalendarDays },
    { to: '/admin/performance', label: 'Performance & AI', icon: TrendingUp },
  ];

  const employeeLinks = [
    { to: '/dashboard', label: 'My Dashboard', icon: LayoutDashboard },
    { to: '/my-tasks', label: 'My Tasks', icon: CheckSquare },
    { to: '/my-attendance', label: 'My Attendance', icon: Clock },
    { to: '/my-leave', label: 'Time Off & Leave', icon: CalendarDays },
    { to: '/my-performance', label: 'Performance Score', icon: TrendingUp },
    { to: '/profile', label: 'My Profile', icon: UserCheck },
  ];

  const navLinks = isAdmin ? adminLinks : employeeLinks;

  const sidebarClasses = `
    fixed inset-y-0 left-0 z-50 w-64 bg-white/95 dark:bg-slate-950/95 backdrop-blur-2xl border-r border-slate-200 dark:border-slate-800/80 transform transition-transform duration-300 ease-in-out
    lg:translate-x-0 lg:static lg:z-auto
    ${isOpen ? 'translate-x-0' : '-translate-x-full'}
  `;

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm lg:hidden"
        ></div>
      )}

      <aside className={sidebarClasses}>
        <div className="flex flex-col h-full">
          {/* Header & Logo */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-slate-200 dark:border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-extrabold tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 dark:from-white via-slate-800 dark:via-slate-200 to-indigo-500">
                  DAYFLOW
                </h1>
                <p className="text-[10px] uppercase font-bold tracking-widest text-indigo-500 dark:text-indigo-400">HR SaaS Suite</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
            <div className="px-3 pb-2 text-[10px] font-bold tracking-widest text-slate-400 uppercase">
              {isAdmin ? 'Management Console' : 'Employee Workspace'}
            </div>
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <NavLink
                  key={link.to}
                  to={link.to}
                  onClick={onClose}
                  className={({ isActive }) => `
                    flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
                    ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 border border-indigo-500/30'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900/60'
                    }
                  `}
                >
                  <Icon className="w-4 h-4" />
                  <span>{link.label}</span>
                </NavLink>
              );
            })}
          </nav>

          {/* Bottom Card Footer */}
          <div className="p-4 border-t border-slate-200 dark:border-slate-800/80">
            <div className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800/80 text-xs">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-slate-700 dark:text-slate-300">Dayflow Cloud</span>
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Production v1.0.4 Online</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
