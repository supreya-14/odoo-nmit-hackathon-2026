import api from './api';

export const leaveService = {
  apply: async (data) => {
    const res = await api.post('/leaves', data);
    return res.data;
  },
  getMyLeaves: async () => {
    const res = await api.get('/leaves/my');
    return res.data;
  },
  getAllLeaves: async () => {
    const res = await api.get('/leaves/all');
    return res.data;
  },
  approve: async (id) => {
    const res = await api.put(`/leaves/${id}/approve`);
    return res.data;
  },
  reject: async (id, reason) => {
    const res = await api.put(`/leaves/${id}/reject`, { rejectionReason: reason });
    return res.data;
  },
};
