const dotenv = require('dotenv');
const connectDB = require('../config/db');
const User = require('../models/User');
const Employee = require('../models/Employee');
const Task = require('../models/Task');
const Attendance = require('../models/Attendance');
const Leave = require('../models/Leave');
const Performance = require('../models/Performance');

dotenv.config();

const seedData = async () => {
  try {
    await connectDB();

    console.log('Clearing old collections...');
    await User.deleteMany({});
    await Employee.deleteMany({});
    await Task.deleteMany({});
    await Attendance.deleteMany({});
    await Leave.deleteMany({});
    await Performance.deleteMany({});

    console.log('Seeding Users and Employees...');

    // 1. Admin User
    const adminUser = await User.create({
      employeeId: 'OT-ADMI-2023-0001',
      email: 'admin@dayflow.com',
      password: 'Admin@123',
      role: 'ADMIN',
      isFirstLogin: false,
    });

    const adminEmp = await Employee.create({
      userId: adminUser._id,
      employeeId: 'OT-ADMI-2023-0001',
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@dayflow.com',
      phone: '+1 (555) 019-2834',
      company: 'OneTech Solutions',
      department: 'Human Resources',
      jobPosition: 'HR Director',
      manager: 'Board of Directors',
      location: 'New York, USA',
      joiningDate: new Date('2023-01-15'),
      skills: ['HR Strategy', 'Talent Acquisition', 'Performance Management'],
      salary: {
        wageType: 'MONTHLY',
        monthlyWage: 85000,
        yearlyWage: 1020000,
        basicSalary: 42500,
        hra: 21250,
        standardAllowance: 8500,
        performanceBonus: 8500,
        lta: 4250,
        fixedAllowance: 0,
        providentFund: 5100,
        professionalTax: 200,
        workingDays: 22,
        breakTime: 60,
      },
    });

    // 2. Employee 1 - John Doe
    const emp1User = await User.create({
      employeeId: 'OT-JODO-2023-0002',
      email: 'john.doe@dayflow.com',
      password: 'Password@123',
      role: 'EMPLOYEE',
      isFirstLogin: false,
    });

    const emp1 = await Employee.create({
      userId: emp1User._id,
      employeeId: 'OT-JODO-2023-0002',
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@dayflow.com',
      phone: '+1 (555) 014-9821',
      company: 'OneTech Solutions',
      department: 'Engineering',
      jobPosition: 'Senior Full Stack Developer',
      manager: 'Sarah Jenkins',
      location: 'San Francisco, USA',
      joiningDate: new Date('2023-03-10'),
      skills: ['React', 'Node.js', 'MongoDB', 'Tailwind CSS', 'TypeScript'],
      salary: {
        wageType: 'MONTHLY',
        monthlyWage: 60000,
        yearlyWage: 720000,
        basicSalary: 30000,
        hra: 15000,
        standardAllowance: 6000,
        performanceBonus: 6000,
        lta: 3000,
        fixedAllowance: 0,
        providentFund: 3600,
        professionalTax: 200,
        workingDays: 22,
        breakTime: 60,
      },
    });

    // 3. Employee 2 - Jane Smith
    const emp2User = await User.create({
      employeeId: 'OT-JASM-2023-0003',
      email: 'jane.smith@dayflow.com',
      password: 'Password@123',
      role: 'EMPLOYEE',
      isFirstLogin: false,
    });

    const emp2 = await Employee.create({
      userId: emp2User._id,
      employeeId: 'OT-JASM-2023-0003',
      firstName: 'Jane',
      lastName: 'Smith',
      email: 'jane.smith@dayflow.com',
      phone: '+1 (555) 018-4421',
      company: 'OneTech Solutions',
      department: 'Design',
      jobPosition: 'Lead UI/UX Designer',
      manager: 'Sarah Jenkins',
      location: 'Austin, USA',
      joiningDate: new Date('2023-05-20'),
      skills: ['Figma', 'UI Systems', 'User Research', 'Prototyping'],
      salary: {
        wageType: 'MONTHLY',
        monthlyWage: 55000,
        yearlyWage: 660000,
        basicSalary: 27500,
        hra: 13750,
        standardAllowance: 5500,
        performanceBonus: 5500,
        lta: 2750,
        fixedAllowance: 0,
        providentFund: 3300,
        professionalTax: 200,
        workingDays: 22,
        breakTime: 60,
      },
    });

    console.log('Seeding Tasks...');
    await Task.create([
      {
        title: 'Build Dayflow REST API & Auth System',
        description: 'Implement Express routes for Authentication, Employee Management, and JWT validation.',
        assignedTo: emp1._id,
        createdBy: adminUser._id,
        priority: 'URGENT',
        status: 'COMPLETED',
        dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
        progress: 100,
        comments: [{ authorId: emp1User._id, authorName: 'John Doe', text: 'JWT Auth and validation done!' }],
      },
      {
        title: 'Redesign Performance Analytics Dashboard',
        description: 'Craft glassmorphism cards and charts using Recharts for overall score and attendance distribution.',
        assignedTo: emp2._id,
        createdBy: adminUser._id,
        priority: 'HIGH',
        status: 'IN_PROGRESS',
        dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        progress: 65,
        comments: [{ authorId: emp2User._id, authorName: 'Jane Smith', text: 'Figma mockups approved.' }],
      },
    ]);

    console.log('Seeding Attendance Records...');
    await Attendance.create([
      {
        employeeId: emp1._id,
        date: new Date(),
        checkIn: new Date(Date.now() - 4 * 60 * 60 * 1000),
        workHours: 4.0,
        status: 'PRESENT',
      },
      {
        employeeId: emp2._id,
        date: new Date(),
        checkIn: new Date(Date.now() - 3 * 60 * 60 * 1000),
        workHours: 3.0,
        status: 'PRESENT',
      },
    ]);

    console.log('Seeding Leaves...');
    await Leave.create([
      {
        employeeId: emp1._id,
        leaveType: 'Paid Time Off',
        startDate: new Date('2026-09-01'),
        endDate: new Date('2026-09-03'),
        numberOfDays: 3,
        reason: 'Annual family vacation.',
        status: 'APPROVED',
        approvedBy: adminUser._id,
        approvedAt: new Date(),
      },
      {
        employeeId: emp2._id,
        leaveType: 'Sick Leave',
        startDate: new Date('2026-08-30'),
        endDate: new Date('2026-08-30'),
        numberOfDays: 1,
        reason: 'Medical checkup.',
        status: 'PENDING',
      },
    ]);

    console.log('Seeding Performance Records...');
    await Performance.create([
      {
        employeeId: emp1._id,
        taskCompletionScore: 92,
        attendanceScore: 95,
        onTimeDeliveryScore: 90,
        productivityScore: 94,
        overallScore: 92.6,
        strengths: ['Full-stack mastery', 'Clean code practices'],
        weaknesses: ['API documentation'],
        suggestions: ['Lead architecture sessions'],
        managerFeedback: 'John is performant and consistent.',
        reviewPeriod: 'Q3 2026',
        aiInsights: {
          summary: 'John Doe demonstrates top-tier efficiency and reliable attendance.',
          strengths: ['High throughput', 'Punctual deliverable submission'],
          areasForImprovement: ['Technical documentation'],
          recommendedGoals: ['Publish API docs for v2 endpoints'],
        },
      },
      {
        employeeId: emp2._id,
        taskCompletionScore: 88,
        attendanceScore: 92,
        onTimeDeliveryScore: 86,
        productivityScore: 90,
        overallScore: 88.8,
        strengths: ['Design vision', 'Prototyping speed'],
        weaknesses: ['Component handoff detail'],
        suggestions: ['Build design system guidelines'],
        managerFeedback: 'Jane provides excellent UI/UX leadership.',
        reviewPeriod: 'Q3 2026',
        aiInsights: {
          summary: 'Jane Smith excels in design quality and sprint collaboration.',
          strengths: ['User-centered UI design', 'Rapid prototyping'],
          areasForImprovement: ['Design tokens documentation'],
          recommendedGoals: ['Formalize UI component tokens library'],
        },
      },
    ]);

    console.log('Database seeding successfully completed!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding Failed:', error.message);
    process.exit(1);
  }
};

seedData();
