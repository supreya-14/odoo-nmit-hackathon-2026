export const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const TASK_STATUS = {
  TODO: { label: 'To Do', color: 'bg-slate-700 text-slate-200' },
  IN_PROGRESS: { label: 'In Progress', color: 'bg-indigo-900/60 text-indigo-300 border border-indigo-700/50' },
  REVIEW: { label: 'In Review', color: 'bg-purple-900/60 text-purple-300 border border-purple-700/50' },
  COMPLETED: { label: 'Completed', color: 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/50' },
  OVERDUE: { label: 'Overdue', color: 'bg-rose-900/60 text-rose-300 border border-rose-700/50' },
};

export const TASK_PRIORITY = {
  LOW: { label: 'Low', color: 'text-slate-400 bg-slate-800' },
  MEDIUM: { label: 'Medium', color: 'text-amber-400 bg-amber-950/60 border border-amber-800/40' },
  HIGH: { label: 'High', color: 'text-orange-400 bg-orange-950/60 border border-orange-800/40' },
  URGENT: { label: 'Urgent', color: 'text-rose-400 bg-rose-950/60 border border-rose-800/40 font-bold' },
};

export const LEAVE_STATUS = {
  PENDING: { label: 'Pending', color: 'bg-amber-950/60 text-amber-300 border border-amber-800/50' },
  APPROVED: { label: 'Approved', color: 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50' },
  REJECTED: { label: 'Rejected', color: 'bg-rose-950/60 text-rose-300 border border-rose-800/50' },
};
