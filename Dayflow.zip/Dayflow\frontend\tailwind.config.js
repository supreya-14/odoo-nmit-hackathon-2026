/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef2ff',
          100: '#e0e7ff',
          500: '#6366f1',
          600: '#4f46e5',
          700: '#4338ca',
          900: '#312e81',
        },
        dark: {
          bg: '#0B0F17',
          card: '#111827',
          border: '#1F2937',
          hover: '#1E293B',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
      },
      animation: {
        'flow-glow': 'flowGlow 8s ease infinite alternate',
      },
      keyframes: {
        flowGlow: {
          '0%': { transform: 'scale(1) rotate(0deg)', opacity: '0.3' },
          '100%': { transform: 'scale(1.2) rotate(15deg)', opacity: '0.6' },
        },
      },
    },
  },
  plugins: [],
};
